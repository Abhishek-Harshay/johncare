module.exports = [
"[project]/.next-internal/server/app/api/bots/holder/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/lib/services/testnet.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Testnet Configuration Service
// Provides free testing environment for users to build trust
__turbopack_context__.s([
    "TestnetService",
    ()=>TestnetService,
    "testnetService",
    ()=>testnetService
]);
class TestnetService {
    static instance;
    currentNetwork = 'testnet';
    // Network configurations
    networks = {
        mainnet: {
            network: 'mainnet',
            rpcEndpoint: 'https://api.mainnet-beta.solana.com',
            explorerUrl: 'https://explorer.solana.com',
            isFree: false
        },
        testnet: {
            network: 'testnet',
            rpcEndpoint: 'https://api.testnet.solana.com',
            explorerUrl: 'https://explorer.solana.com?cluster=testnet',
            faucetUrl: 'https://faucet.solana.com',
            isFree: true
        },
        devnet: {
            network: 'devnet',
            rpcEndpoint: 'https://api.devnet.solana.com',
            explorerUrl: 'https://explorer.solana.com?cluster=devnet',
            faucetUrl: 'https://faucet.solana.com',
            isFree: true
        }
    };
    static getInstance() {
        if (!TestnetService.instance) {
            TestnetService.instance = new TestnetService();
        }
        return TestnetService.instance;
    }
    getCurrentNetwork() {
        return this.networks[this.currentNetwork];
    }
    setNetwork(network) {
        this.currentNetwork = network;
        console.log(`🔄 Network switched to: ${network.toUpperCase()}`);
    }
    isTestMode() {
        return this.currentNetwork !== 'mainnet';
    }
    getNetworkInfo() {
        return this.getCurrentNetwork();
    }
    // Get appropriate RPC endpoint based on current network
    getRPCEndpoint() {
        const network = this.getCurrentNetwork();
        // Use Helius for better performance if available
        if (this.currentNetwork === 'testnet') {
            const heliusKey = process.env.HELIUS_API_KEY_1;
            if (heliusKey) {
                return `https://devnet.helius-rpc.com/?api-key=${heliusKey}`;
            }
        }
        return network.rpcEndpoint;
    }
    // Get testnet SOL from faucet
    async requestTestnetSOL(publicKey) {
        if (this.currentNetwork === 'mainnet') {
            return {
                success: false,
                message: 'Faucet not available on mainnet'
            };
        }
        try {
            const network = this.getCurrentNetwork();
            if (!network.faucetUrl) {
                return {
                    success: false,
                    message: 'Faucet not available for this network'
                };
            }
            // Simulate faucet request (in real implementation, call actual faucet API)
            console.log(`💧 Requesting testnet SOL for: ${publicKey}`);
            // Mock successful faucet response
            const mockTxHash = `faucet_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            return {
                success: true,
                message: `Successfully airdropped 2 SOL to ${publicKey.slice(0, 8)}...`,
                txHash: mockTxHash
            };
        } catch (error) {
            console.error('Faucet request failed:', error);
            return {
                success: false,
                message: 'Faucet request failed'
            };
        }
    }
    // Generate warning message for testnet usage
    getTestnetWarning() {
        if (this.currentNetwork === 'mainnet') {
            return '⚠️ You are on MAINNET - Real tokens and SOL will be used!';
        }
        return `ℹ️ You are on ${this.currentNetwork.toUpperCase()} - This is a free testing environment. No real value involved.`;
    }
    // Get network-specific explorer URL
    getExplorerUrl(signature) {
        const network = this.getCurrentNetwork();
        const baseUrl = network.explorerUrl;
        if (signature) {
            return `${baseUrl}/tx/${signature}`;
        }
        return baseUrl;
    }
    // Testnet-specific token creation parameters
    getTokenCreationConfig() {
        return {
            network: this.currentNetwork,
            isFree: this.isTestMode(),
            rpcEndpoint: this.getRPCEndpoint(),
            explorerUrl: this.getCurrentNetwork().explorerUrl,
            warning: this.getTestnetWarning(),
            features: {
                freeCreation: this.isTestMode(),
                freeLiquidity: this.isTestMode(),
                freeTransactions: this.isTestMode(),
                testnetFaucet: this.isTestMode()
            }
        };
    }
}
const testnetService = TestnetService.getInstance();
}),
"[project]/src/lib/services/bots/holderGenerator.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "holderGeneratorService",
    ()=>holderGeneratorService
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$testnet$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/services/testnet.ts [app-route] (ecmascript)");
;
class HolderGeneratorService {
    sessions = new Map();
    wallets = new Map();
    intervals = new Map();
    // Generate unique session ID
    generateSessionId() {
        return `holder_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }
    // Generate wallet address (simulation)
    generateWallet() {
        const address = Array.from({
            length: 44
        }, ()=>'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz123456789'[Math.floor(Math.random() * 58)]).join('');
        const privateKey = Array.from({
            length: 88
        }, ()=>'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz123456789'[Math.floor(Math.random() * 58)]).join('');
        return {
            address,
            privateKey,
            balance: 0,
            createdAt: new Date().toISOString(),
            active: true
        };
    }
    // Calculate balance based on holder pattern
    calculateBalance(config, holderIndex) {
        const { minBalance, maxBalance, holderPattern, targetHolders } = config;
        const position = holderIndex / targetHolders;
        switch(holderPattern){
            case 'whale-heavy':
                // 20% whales, 80% smaller holders
                if (position < 0.2) {
                    return maxBalance * (0.5 + Math.random() * 0.5) // 50-100% of max
                    ;
                }
                return minBalance + Math.random() * (maxBalance * 0.1);
            case 'retail-focused':
                // Mostly small holders with few medium holders
                const variance = Math.random();
                if (variance > 0.9) {
                    return maxBalance * (0.1 + Math.random() * 0.3) // 10-40% of max
                    ;
                }
                return minBalance + Math.random() * (minBalance * 5);
            case 'balanced':
                // Even distribution with some randomness
                const tier = Math.random();
                if (tier < 0.1) return maxBalance * (0.7 + Math.random() * 0.3) // Top 10%
                ;
                if (tier < 0.3) return maxBalance * (0.3 + Math.random() * 0.4) // Next 20%
                ;
                return minBalance + Math.random() * (maxBalance * 0.3);
            case 'natural':
            default:
                // Power law distribution (more realistic)
                const power = Math.pow(Math.random(), 2.5) // Pareto-like distribution
                ;
                return minBalance + power * (maxBalance - minBalance);
        }
    }
    // Start holder generation session
    async startSession(config) {
        try {
            // Validate configuration
            if (!config.tokenAddress) {
                return {
                    success: false,
                    message: 'Token address is required'
                };
            }
            if (config.targetHolders < 10 || config.targetHolders > 10000) {
                return {
                    success: false,
                    message: 'Target holders must be between 10 and 10,000'
                };
            }
            if (config.minBalance >= config.maxBalance) {
                return {
                    success: false,
                    message: 'Minimum balance must be less than maximum balance'
                };
            }
            // Check if using testnet for validation
            const isTestMode = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$testnet$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["testnetService"].isTestMode();
            if (!isTestMode) {
                console.log('🚨 Mainnet holder generation - Use with caution!');
            }
            const sessionId = this.generateSessionId();
            const session = {
                id: sessionId,
                config,
                status: 'running',
                startTime: new Date().toISOString(),
                currentHolders: 0,
                targetHolders: config.targetHolders,
                walletsCreated: 0,
                totalDistributed: 0,
                averageBalance: 0,
                errors: []
            };
            this.sessions.set(sessionId, session);
            this.wallets.set(sessionId, []);
            // Start holder generation process
            await this.startHolderGeneration(sessionId);
            return {
                success: true,
                sessionId,
                message: 'Holder generation started successfully'
            };
        } catch (error) {
            console.error('Failed to start holder generation session:', error);
            return {
                success: false,
                message: 'Failed to start holder generation session'
            };
        }
    }
    // Start the holder generation process
    async startHolderGeneration(sessionId) {
        const session = this.sessions.get(sessionId);
        if (!session) return;
        const { config } = session;
        const intervalMs = 60 * 1000 / config.distributionSpeed // Convert holders/min to ms interval
        ;
        const interval = setInterval(async ()=>{
            try {
                const currentSession = this.sessions.get(sessionId);
                if (!currentSession || currentSession.status !== 'running') {
                    clearInterval(interval);
                    this.intervals.delete(sessionId);
                    return;
                }
                // Generate new holders
                const holdersToCreate = Math.min(1, currentSession.targetHolders - currentSession.currentHolders);
                if (holdersToCreate <= 0) {
                    await this.completeSession(sessionId);
                    clearInterval(interval);
                    this.intervals.delete(sessionId);
                    return;
                }
                for(let i = 0; i < holdersToCreate; i++){
                    await this.createHolder(sessionId, currentSession.currentHolders + i);
                }
                // Update session progress
                currentSession.currentHolders += holdersToCreate;
                currentSession.walletsCreated += holdersToCreate;
                // Recalculate average balance
                const wallets = this.wallets.get(sessionId) || [];
                const totalBalance = wallets.reduce((sum, wallet)=>sum + wallet.balance, 0);
                currentSession.averageBalance = wallets.length > 0 ? totalBalance / wallets.length : 0;
                currentSession.totalDistributed = totalBalance;
                this.sessions.set(sessionId, currentSession);
                console.log(`📊 Holder generation progress: ${currentSession.currentHolders}/${currentSession.targetHolders} holders created`);
            } catch (error) {
                console.error('Error in holder generation:', error);
                const currentSession = this.sessions.get(sessionId);
                if (currentSession) {
                    currentSession.errors.push(`Generation error: ${error instanceof Error ? error.message : 'Unknown error'}`);
                    this.sessions.set(sessionId, currentSession);
                }
            }
        }, intervalMs);
        this.intervals.set(sessionId, interval);
    }
    // Create individual holder
    async createHolder(sessionId, holderIndex) {
        const session = this.sessions.get(sessionId);
        const wallets = this.wallets.get(sessionId);
        if (!session || !wallets) return;
        try {
            // Generate new wallet
            const wallet = this.generateWallet();
            // Calculate balance based on holder pattern
            wallet.balance = this.calculateBalance(session.config, holderIndex);
            // Simulate token distribution (in testnet, this is just simulation)
            const isTestMode = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$testnet$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["testnetService"].isTestMode();
            if (isTestMode) {
                console.log(`🧪 [TESTNET] Simulating token distribution to ${wallet.address.slice(0, 8)}... - Balance: ${wallet.balance.toLocaleString()}`);
            } else {
                console.log(`💰 [MAINNET] Would distribute ${wallet.balance.toLocaleString()} tokens to ${wallet.address.slice(0, 8)}...`);
            // In mainnet, actual token distribution logic would go here
            }
            wallets.push(wallet);
            this.wallets.set(sessionId, wallets);
        } catch (error) {
            console.error('Failed to create holder:', error);
            throw error;
        }
    }
    // Complete session
    async completeSession(sessionId) {
        const session = this.sessions.get(sessionId);
        if (!session) return;
        session.status = 'completed';
        session.endTime = new Date().toISOString();
        // Apply retention rate (some holders might sell/become inactive)
        const wallets = this.wallets.get(sessionId) || [];
        const retainedCount = Math.floor(wallets.length * (session.config.retentionRate / 100));
        // Mark some wallets as inactive based on retention rate
        const walletsToDeactivate = wallets.length - retainedCount;
        for(let i = 0; i < walletsToDeactivate; i++){
            const randomIndex = Math.floor(Math.random() * wallets.length);
            if (wallets[randomIndex] && wallets[randomIndex].active) {
                wallets[randomIndex].active = false;
            }
        }
        session.currentHolders = retainedCount;
        this.sessions.set(sessionId, session);
        this.wallets.set(sessionId, wallets);
        console.log(`✅ Holder generation completed for session ${sessionId}`);
        console.log(`📊 Final stats: ${retainedCount} active holders, ${session.totalDistributed.toLocaleString()} tokens distributed`);
    }
    // Pause session
    async pauseSession(sessionId) {
        const session = this.sessions.get(sessionId);
        if (!session) {
            return {
                success: false,
                message: 'Session not found'
            };
        }
        if (session.status !== 'running') {
            return {
                success: false,
                message: 'Session is not running'
            };
        }
        session.status = 'paused';
        this.sessions.set(sessionId, session);
        // Clear interval
        const interval = this.intervals.get(sessionId);
        if (interval) {
            clearInterval(interval);
            this.intervals.delete(sessionId);
        }
        return {
            success: true,
            message: 'Session paused successfully'
        };
    }
    // Resume session
    async resumeSession(sessionId) {
        const session = this.sessions.get(sessionId);
        if (!session) {
            return {
                success: false,
                message: 'Session not found'
            };
        }
        if (session.status !== 'paused') {
            return {
                success: false,
                message: 'Session is not paused'
            };
        }
        session.status = 'running';
        this.sessions.set(sessionId, session);
        // Restart holder generation
        await this.startHolderGeneration(sessionId);
        return {
            success: true,
            message: 'Session resumed successfully'
        };
    }
    // Stop session
    async stopSession(sessionId) {
        const session = this.sessions.get(sessionId);
        if (!session) {
            return {
                success: false,
                message: 'Session not found'
            };
        }
        session.status = 'completed';
        session.endTime = new Date().toISOString();
        this.sessions.set(sessionId, session);
        // Clear interval
        const interval = this.intervals.get(sessionId);
        if (interval) {
            clearInterval(interval);
            this.intervals.delete(sessionId);
        }
        return {
            success: true,
            message: 'Session stopped successfully'
        };
    }
    // Get session status
    getSession(sessionId) {
        return this.sessions.get(sessionId) || null;
    }
    // Get all sessions
    getAllSessions() {
        return Array.from(this.sessions.values());
    }
    // Get wallets for a session
    getSessionWallets(sessionId) {
        return this.wallets.get(sessionId) || [];
    }
    // Export wallets to CSV format
    exportWallets(sessionId) {
        const wallets = this.wallets.get(sessionId) || [];
        const csvHeader = 'Address,PrivateKey,Balance,CreatedAt,Active';
        const csvRows = wallets.map((wallet)=>`${wallet.address},${wallet.privateKey},${wallet.balance},${wallet.createdAt},${wallet.active}`);
        return [
            csvHeader,
            ...csvRows
        ].join('\n');
    }
    // Get holder distribution stats
    getHolderStats(sessionId) {
        const wallets = this.wallets.get(sessionId) || [];
        if (wallets.length === 0) return null;
        const activeWallets = wallets.filter((w)=>w.active);
        const balances = activeWallets.map((w)=>w.balance).sort((a, b)=>a - b);
        const totalDistributed = balances.reduce((sum, balance)=>sum + balance, 0);
        return {
            totalHolders: wallets.length,
            activeHolders: activeWallets.length,
            totalDistributed,
            averageBalance: totalDistributed / activeWallets.length,
            medianBalance: balances[Math.floor(balances.length / 2)],
            whaleHolders: balances.filter((b)=>b > 1000000).length,
            retailHolders: balances.filter((b)=>b < 10000).length
        };
    }
    // Cleanup completed sessions (optional)
    cleanup() {
        let cleaned = 0;
        const cutoffTime = Date.now() - 24 * 60 * 60 * 1000 // 24 hours ago
        ;
        for (const [sessionId, session] of this.sessions.entries()){
            if (session.status === 'completed' && session.endTime) {
                const endTime = new Date(session.endTime).getTime();
                if (endTime < cutoffTime) {
                    this.sessions.delete(sessionId);
                    this.wallets.delete(sessionId);
                    const interval = this.intervals.get(sessionId);
                    if (interval) {
                        clearInterval(interval);
                        this.intervals.delete(sessionId);
                    }
                    cleaned++;
                }
            }
        }
        if (cleaned > 0) {
            console.log(`🧹 Cleaned up ${cleaned} old holder generation sessions`);
        }
        return cleaned;
    }
}
const holderGeneratorService = new HolderGeneratorService();
}),
"[project]/src/app/api/bots/holder/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET,
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$holderGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/services/bots/holderGenerator.ts [app-route] (ecmascript)");
;
;
async function GET(request) {
    try {
        const { searchParams } = new URL(request.url);
        const sessionId = searchParams.get('sessionId');
        if (sessionId) {
            // Get specific session
            const session = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$holderGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["holderGeneratorService"].getSession(sessionId);
            if (!session) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    success: false,
                    message: 'Session not found'
                }, {
                    status: 404
                });
            }
            // Get additional stats
            const stats = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$holderGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["holderGeneratorService"].getHolderStats(sessionId);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: true,
                session: {
                    ...session,
                    stats
                }
            });
        }
        // Get all sessions
        const sessions = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$holderGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["holderGeneratorService"].getAllSessions();
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            sessions,
            count: sessions.length
        });
    } catch (error) {
        console.error('Holder Generator API Error (GET):', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            message: 'Internal server error'
        }, {
            status: 500
        });
    }
}
async function POST(request) {
    try {
        const body = await request.json();
        const { action, config, sessionId } = body;
        switch(action){
            case 'start':
                {
                    if (!config) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Configuration is required'
                        }, {
                            status: 400
                        });
                    }
                    // Validate required fields
                    if (!config.tokenAddress) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Token address is required'
                        }, {
                            status: 400
                        });
                    }
                    if (!config.targetHolders || config.targetHolders < 10 || config.targetHolders > 10000) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Target holders must be between 10 and 10,000'
                        }, {
                            status: 400
                        });
                    }
                    // Start new holder generation session
                    const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$holderGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["holderGeneratorService"].startSession({
                        tokenAddress: config.tokenAddress,
                        targetHolders: parseInt(config.targetHolders),
                        duration: parseInt(config.duration) || 120,
                        minBalance: parseFloat(config.minBalance) || 1000,
                        maxBalance: parseFloat(config.maxBalance) || 100000,
                        holderPattern: config.holderPattern || 'natural',
                        retentionRate: parseInt(config.retentionRate) || 85,
                        distributionSpeed: parseInt(config.distributionSpeed) || 2
                    });
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(result, {
                        status: result.success ? 200 : 400
                    });
                }
            case 'pause':
                {
                    if (!sessionId) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Session ID is required'
                        }, {
                            status: 400
                        });
                    }
                    const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$holderGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["holderGeneratorService"].pauseSession(sessionId);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(result, {
                        status: result.success ? 200 : 400
                    });
                }
            case 'resume':
                {
                    if (!sessionId) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Session ID is required'
                        }, {
                            status: 400
                        });
                    }
                    const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$holderGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["holderGeneratorService"].resumeSession(sessionId);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(result, {
                        status: result.success ? 200 : 400
                    });
                }
            case 'stop':
                {
                    if (!sessionId) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Session ID is required'
                        }, {
                            status: 400
                        });
                    }
                    const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$holderGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["holderGeneratorService"].stopSession(sessionId);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(result, {
                        status: result.success ? 200 : 400
                    });
                }
            case 'status':
                {
                    if (!sessionId) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Session ID is required'
                        }, {
                            status: 400
                        });
                    }
                    const session = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$holderGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["holderGeneratorService"].getSession(sessionId);
                    if (!session) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Session not found'
                        }, {
                            status: 404
                        });
                    }
                    const stats = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$holderGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["holderGeneratorService"].getHolderStats(sessionId);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                        success: true,
                        session: {
                            ...session,
                            stats
                        }
                    });
                }
            case 'export':
                {
                    if (!sessionId) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Session ID is required'
                        }, {
                            status: 400
                        });
                    }
                    const csvData = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$holderGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["holderGeneratorService"].exportWallets(sessionId);
                    if (!csvData) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'No wallet data found for this session'
                        }, {
                            status: 404
                        });
                    }
                    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"](csvData, {
                        status: 200,
                        headers: {
                            'Content-Type': 'text/csv',
                            'Content-Disposition': `attachment; filename="holders_${sessionId}.csv"`
                        }
                    });
                }
            case 'stats':
                {
                    if (!sessionId) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Session ID is required'
                        }, {
                            status: 400
                        });
                    }
                    const stats = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$holderGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["holderGeneratorService"].getHolderStats(sessionId);
                    if (!stats) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'No stats available for this session'
                        }, {
                            status: 404
                        });
                    }
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                        success: true,
                        stats
                    });
                }
            case 'cleanup':
                {
                    const cleaned = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$holderGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["holderGeneratorService"].cleanup();
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                        success: true,
                        message: `Cleaned up ${cleaned} old sessions`,
                        cleanedSessions: cleaned
                    });
                }
            default:
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    success: false,
                    message: 'Invalid action. Supported actions: start, pause, resume, stop, status, export, stats, cleanup'
                }, {
                    status: 400
                });
        }
    } catch (error) {
        console.error('Holder Generator API Error (POST):', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            message: error instanceof Error ? error.message : 'Internal server error',
            error: ("TURBOPACK compile-time truthy", 1) ? error : "TURBOPACK unreachable"
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__e7d32a5d._.js.map