module.exports = [
"[project]/.next-internal/server/app/api/platform/status/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/lib/services/deepseek.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// DeepSeek AI Service - 10x cheaper than OpenAI
// ==============================================
__turbopack_context__.s([
    "deepSeekService",
    ()=>deepSeekService,
    "default",
    ()=>__TURBOPACK__default__export__,
    "generateWithFallback",
    ()=>generateWithFallback
]);
class DeepSeekService {
    apiKey;
    baseUrl;
    constructor(){
        this.apiKey = process.env.DEEPSEEK_API_KEY || '';
        this.baseUrl = process.env.DEEPSEEK_API_URL || 'https://api.deepseek.com/v1';
    }
    async generateContent(prompt, systemPrompt) {
        try {
            const messages = [];
            if (systemPrompt) {
                messages.push({
                    role: 'system',
                    content: systemPrompt
                });
            }
            messages.push({
                role: 'user',
                content: prompt
            });
            const response = await fetch(`${this.baseUrl}/chat/completions`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.apiKey}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    model: 'deepseek-chat',
                    messages,
                    temperature: 0.7,
                    max_tokens: 2000,
                    stream: false
                })
            });
            if (!response.ok) {
                if (response.status === 402) {
                    console.warn('⚠️ DeepSeek API requires payment, falling back to OpenAI...');
                    return this.generateWithOpenAI(prompt);
                }
                throw new Error(`DeepSeek API error: ${response.status} ${response.statusText}`);
            }
            const data = await response.json();
            return data.choices[0]?.message?.content || 'No response generated';
        } catch (error) {
            console.error('DeepSeek API error:', error);
            console.warn('⚠️ DeepSeek unavailable, falling back to OpenAI...');
            return this.generateWithOpenAI(prompt);
        }
    }
    async generateWithOpenAI(prompt) {
        try {
            const openaiKey = process.env.OPENAI_API_KEY;
            if (!openaiKey) {
                return this.generateMockContent(prompt);
            }
            const response = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${openaiKey}`
                },
                body: JSON.stringify({
                    model: 'gpt-3.5-turbo',
                    messages: [
                        {
                            role: 'user',
                            content: prompt
                        }
                    ],
                    max_tokens: 500,
                    temperature: 0.7
                })
            });
            if (!response.ok) {
                console.warn('⚠️ OpenAI also failed, using mock content');
                return this.generateMockContent(prompt);
            }
            const data = await response.json();
            return data.choices[0]?.message?.content || this.generateMockContent(prompt);
        } catch (error) {
            console.error('OpenAI fallback error:', error);
            return this.generateMockContent(prompt);
        }
    }
    generateMockContent(prompt) {
        // Generate contextual mock content based on prompt keywords
        const lowerPrompt = prompt.toLowerCase();
        if (lowerPrompt.includes('token') && lowerPrompt.includes('description')) {
            return '🚀 Revolutionary token with innovative utility and strong community backing. Built on Solana for lightning-fast transactions and low fees.';
        }
        if (lowerPrompt.includes('marketing') || lowerPrompt.includes('strategy')) {
            return '📈 Multi-channel marketing approach targeting key demographics through social media engagement, influencer partnerships, and community building initiatives.';
        }
        if (lowerPrompt.includes('analysis') || lowerPrompt.includes('market')) {
            return '📊 Market analysis shows strong potential with growing adoption trends, favorable technical indicators, and increasing community interest.';
        }
        if (lowerPrompt.includes('whitepaper')) {
            return '📋 Comprehensive technical documentation outlining tokenomics, utility framework, roadmap milestones, and governance structure for sustainable growth.';
        }
        return '✨ AI-powered content generation currently using fallback mode. Upgrade to premium AI services for enhanced content quality and personalization.';
    }
    // Specialized methods for different platform features
    async generateTokenDescription(tokenName, symbol) {
        const prompt = `Create a compelling description for a token named "${tokenName}" with symbol "${symbol}". Make it professional, engaging, and highlight potential use cases. Keep it under 200 words.`;
        const systemPrompt = 'You are an expert crypto marketing specialist. Create professional, compliant token descriptions that attract investors while being honest about risks.';
        return this.generateContent(prompt, systemPrompt);
    }
    async generateMemeTokenContent(tokenName, theme) {
        const prompt = `Create meme token content for "${tokenName}" with theme "${theme}". Include: 1) Fun description 2) Catchy tagline 3) List of 5 fun features. Make it engaging and community-focused.`;
        const systemPrompt = 'You are a meme coin marketing expert. Create fun, engaging content that builds community while being responsible about investment risks.';
        const response = await this.generateContent(prompt, systemPrompt);
        try {
            // Parse the structured response
            const lines = response.split('\n').filter((line)=>line.trim());
            return {
                description: lines.find((line)=>line.includes('Description:'))?.replace('Description:', '').trim() || response.slice(0, 200),
                tagline: lines.find((line)=>line.includes('Tagline:'))?.replace('Tagline:', '').trim() || 'To the moon! 🚀',
                features: lines.filter((line)=>line.match(/^\d+\./)).map((line)=>line.replace(/^\d+\./, '').trim()).slice(0, 5)
            };
        } catch  {
            // Fallback if parsing fails
            return {
                description: response.slice(0, 200),
                tagline: 'To the moon! 🚀',
                features: [
                    'Community Driven',
                    'Meme Power',
                    'Diamond Hands',
                    'Moon Mission',
                    'Fun & Profits'
                ]
            };
        }
    }
    async generateWebsiteContent(projectName, projectType) {
        const prompt = `Generate website content for "${projectName}" (${projectType} project). Include: hero title, subtitle, 4 key features, and about section. Make it professional and conversion-focused.`;
        const systemPrompt = 'You are a web copywriting expert specializing in crypto and DeFi projects. Create compelling, professional content that converts visitors.';
        const response = await this.generateContent(prompt, systemPrompt);
        try {
            const lines = response.split('\n').filter((line)=>line.trim());
            return {
                heroTitle: lines.find((line)=>line.includes('Title:'))?.replace('Title:', '').trim() || projectName,
                heroSubtitle: lines.find((line)=>line.includes('Subtitle:'))?.replace('Subtitle:', '').trim() || 'Revolutionary DeFi Solution',
                features: lines.filter((line)=>line.match(/^[\-\*]\s/)).map((line)=>line.replace(/^[\-\*]\s/, '')).slice(0, 4),
                aboutText: lines.slice(-3).join(' ').trim() || 'Built for the future of decentralized finance.'
            };
        } catch  {
            return {
                heroTitle: projectName,
                heroSubtitle: 'Revolutionary DeFi Solution',
                features: [
                    'Secure Trading',
                    'Low Fees',
                    'Fast Transactions',
                    'Community Driven'
                ],
                aboutText: 'Built for the future of decentralized finance.'
            };
        }
    }
    async analyzeTradingStrategy(tokenData) {
        const prompt = `Analyze this token data and provide trading insights: ${JSON.stringify(tokenData)}. Include technical analysis, risk assessment, and potential strategies.`;
        const systemPrompt = 'You are a professional crypto analyst. Provide objective analysis with clear risk warnings. Never give direct financial advice.';
        return this.generateContent(prompt, systemPrompt);
    }
    // Check if DeepSeek is available and working
    async testConnection() {
        try {
            const response = await this.generateContent('Test connection', 'Respond with: Connection successful');
            return response.includes('successful') || response.includes('working') || response.includes('Connection');
        } catch (error) {
            console.log('⚠️ DeepSeek unavailable, will fallback to OpenAI:', error);
            return false;
        }
    }
}
const deepSeekService = new DeepSeekService();
async function generateWithFallback(prompt, systemPrompt) {
    try {
        // Try DeepSeek first (10x cheaper)
        return await deepSeekService.generateContent(prompt, systemPrompt);
    } catch (error) {
        console.log('DeepSeek failed, falling back to OpenAI:', error);
        // Fallback to OpenAI
        try {
            const response = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    model: 'gpt-3.5-turbo',
                    messages: [
                        ...systemPrompt ? [
                            {
                                role: 'system',
                                content: systemPrompt
                            }
                        ] : [],
                        {
                            role: 'user',
                            content: prompt
                        }
                    ],
                    temperature: 0.7,
                    max_tokens: 2000
                })
            });
            const data = await response.json();
            return data.choices[0]?.message?.content || 'No response generated';
        } catch (openaiError) {
            console.error('Both DeepSeek and OpenAI failed:', openaiError);
            throw new Error('AI services unavailable');
        }
    }
}
const __TURBOPACK__default__export__ = DeepSeekService;
}),
"[project]/src/lib/services/helius.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Helius API Service - Premium Solana RPC & Data
// ===============================================
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "heliusService",
    ()=>heliusService
]);
class HeliusService {
    apiKeys;
    currentKeyIndex;
    baseUrl;
    constructor(){
        this.apiKeys = [
            process.env.HELIUS_API_KEY_1 || '',
            process.env.HELIUS_API_KEY_2 || '',
            process.env.HELIUS_API_KEY_3 || '',
            process.env.HELIUS_API_KEY_4 || '',
            process.env.HELIUS_API_KEY_5 || '',
            process.env.HELIUS_API_KEY_6 || ''
        ].filter((key)=>key && key.length > 10); // Filter out empty or placeholder keys
        this.currentKeyIndex = 0;
        this.baseUrl = 'https://api.helius.xyz/v0';
        console.log(`🔑 Helius Service initialized with ${this.apiKeys.length} API keys`);
    }
    getCurrentApiKey() {
        if (this.apiKeys.length === 0) {
            throw new Error('No valid Helius API keys configured');
        }
        return this.apiKeys[this.currentKeyIndex];
    }
    rotateApiKey() {
        this.currentKeyIndex = (this.currentKeyIndex + 1) % this.apiKeys.length;
    }
    async makeRequest(endpoint, options = {}) {
        const maxRetries = this.apiKeys.length;
        let lastError = null;
        for(let attempt = 0; attempt < maxRetries; attempt++){
            try {
                const apiKey = this.getCurrentApiKey();
                const url = `${this.baseUrl}${endpoint}?api-key=${apiKey}`;
                const response = await fetch(url, {
                    headers: {
                        'Content-Type': 'application/json',
                        ...options.headers
                    },
                    ...options
                });
                if (!response.ok) {
                    if (response.status === 429 || response.status === 403) {
                        // Rate limited or forbidden, try next key
                        this.rotateApiKey();
                        continue;
                    }
                    throw new Error(`Helius API error: ${response.status} ${response.statusText}`);
                }
                return await response.json();
            } catch (error) {
                lastError = error;
                this.rotateApiKey();
            }
        }
        throw new Error(`All Helius API keys failed: ${lastError?.message || 'Unknown error'}`);
    }
    // Get token information
    async getTokenInfo(mintAddress) {
        try {
            const data = await this.makeRequest(`/tokens/${mintAddress}`);
            return {
                mint: data.mint || mintAddress,
                name: data.name || 'Unknown Token',
                symbol: data.symbol || 'UNKNOWN',
                decimals: data.decimals || 9,
                supply: data.supply || '0',
                holders: data.holders || 0,
                marketCap: data.marketCap,
                price: data.price
            };
        } catch (error) {
            console.error('Failed to fetch token info:', error);
            throw new Error('Failed to fetch token information');
        }
    }
    // Get wallet balance and tokens
    async getWalletData(address) {
        try {
            const [balanceData, tokensData] = await Promise.all([
                this.makeRequest(`/addresses/${address}/balances`),
                this.makeRequest(`/addresses/${address}/tokens`)
            ]);
            return {
                address,
                lamports: balanceData.lamports || 0,
                tokens: tokensData.tokens || []
            };
        } catch (error) {
            console.error('Failed to fetch wallet data:', error);
            throw new Error('Failed to fetch wallet information');
        }
    }
    // Get recent transactions
    async getTransactionHistory(address, limit = 10) {
        try {
            const data = await this.makeRequest(`/addresses/${address}/transactions?limit=${limit}`);
            return (data.transactions || []).map((tx)=>({
                    signature: tx.signature,
                    slot: tx.slot,
                    blockTime: tx.blockTime,
                    status: tx.meta?.err ? 'failed' : 'success',
                    fee: tx.meta?.fee || 0,
                    instructions: tx.transaction?.message?.instructions || []
                }));
        } catch (error) {
            console.error('Failed to fetch transaction history:', error);
            return [];
        }
    }
    // Get token holders
    async getTokenHolders(mintAddress, limit = 100) {
        try {
            const data = await this.makeRequest(`/tokens/${mintAddress}/holders?limit=${limit}`);
            return (data.holders || []).map((holder)=>({
                    address: holder.address,
                    amount: holder.amount,
                    percentage: holder.percentage || 0
                }));
        } catch (error) {
            console.error('Failed to fetch token holders:', error);
            return [];
        }
    }
    // Create token (using Helius RPC)
    async createToken(params) {
        try {
            const response = await this.makeRequest('/tokens/create', {
                method: 'POST',
                body: JSON.stringify({
                    name: params.name,
                    symbol: params.symbol,
                    description: params.description,
                    image: params.image,
                    decimals: params.decimals || 9,
                    initialSupply: params.initialSupply || 1000000
                })
            });
            return {
                mint: response.mint,
                signature: response.signature
            };
        } catch (error) {
            console.error('Failed to create token:', error);
            throw new Error('Failed to create token');
        }
    }
    // Get real-time price data
    async getTokenPrice(mintAddress) {
        try {
            const data = await this.makeRequest(`/tokens/${mintAddress}/price`);
            return {
                price: data.price || 0,
                change24h: data.change24h || 0,
                volume24h: data.volume24h || 0
            };
        } catch (error) {
            console.error('Failed to fetch token price:', error);
            return {
                price: 0,
                change24h: 0,
                volume24h: 0
            };
        }
    }
    // Get DEX trades
    async getTokenTrades(mintAddress, limit = 50) {
        try {
            const data = await this.makeRequest(`/tokens/${mintAddress}/trades?limit=${limit}`);
            return (data.trades || []).map((trade)=>({
                    signature: trade.signature,
                    side: trade.side,
                    amount: trade.amount,
                    price: trade.price,
                    timestamp: trade.timestamp,
                    dex: trade.dex || 'unknown'
                }));
        } catch (error) {
            console.error('Failed to fetch token trades:', error);
            return [];
        }
    }
    // Test connection
    async testConnection() {
        try {
            // Use a simple RPC call to test connection
            const apiKey = this.getCurrentApiKey();
            const response = await fetch(`https://mainnet.helius-rpc.com/?api-key=${apiKey}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    jsonrpc: '2.0',
                    id: 1,
                    method: 'getHealth'
                })
            });
            return response.ok;
        } catch (error) {
            console.log('⚠️ Helius connection failed:', error);
            return false;
        }
    }
    // Get RPC URL for direct Solana connection
    getRpcUrl() {
        const apiKey = this.getCurrentApiKey();
        return `https://mainnet.helius-rpc.com/?api-key=${apiKey}`;
    }
}
const heliusService = new HeliusService();
const __TURBOPACK__default__export__ = HeliusService;
}),
"[project]/src/lib/services/coinmarketcap.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// CoinMarketCap API Service - Market Data & Analytics
// ==================================================
__turbopack_context__.s([
    "coinMarketCapService",
    ()=>coinMarketCapService,
    "default",
    ()=>__TURBOPACK__default__export__
]);
class CoinMarketCapService {
    apiKeys;
    currentKeyIndex;
    baseUrl;
    cache = new Map();
    cacheTimeout = 5 * 60 * 1000 // 5 minutes
    ;
    constructor(){
        this.apiKeys = [
            process.env.COINMARKETCAP_API_KEY_1 || '',
            process.env.COINMARKETCAP_API_KEY_2 || '',
            process.env.COINMARKETCAP_API_KEY_3 || '',
            process.env.COINMARKETCAP_API_KEY_4 || '',
            process.env.COINMARKETCAP_API_KEY_5 || '',
            process.env.COINMARKETCAP_API_KEY_6 || '',
            process.env.COINMARKETCAP_API_KEY_7 || '',
            process.env.COINMARKETCAP_API_KEY_8 || ''
        ].filter((key)=>key && key.length > 10); // Filter valid keys
        this.currentKeyIndex = 0;
        this.baseUrl = 'https://pro-api.coinmarketcap.com/v1';
        console.log(`🔑 CoinMarketCap Service initialized with ${this.apiKeys.length} API keys`);
    }
    getCurrentApiKey() {
        if (this.apiKeys.length === 0) {
            throw new Error('No valid CoinMarketCap API keys configured');
        }
        return this.apiKeys[this.currentKeyIndex];
    }
    rotateApiKey() {
        this.currentKeyIndex = (this.currentKeyIndex + 1) % this.apiKeys.length;
        console.log(`🔄 Rotated to CoinMarketCap API key ${this.currentKeyIndex + 1}/${this.apiKeys.length}`);
    }
    async makeRequest(endpoint, params = {}) {
        const cacheKey = `${endpoint}_${JSON.stringify(params)}`;
        const cached = this.cache.get(cacheKey);
        // Return cached data if still valid
        if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
            return cached.data;
        }
        const maxRetries = this.apiKeys.length;
        let lastError = null;
        for(let attempt = 0; attempt < maxRetries; attempt++){
            try {
                const apiKey = this.getCurrentApiKey();
                const queryParams = new URLSearchParams(params);
                const url = `${this.baseUrl}${endpoint}?${queryParams}`;
                const response = await fetch(url, {
                    headers: {
                        'X-CMC_PRO_API_KEY': apiKey,
                        'Accept': 'application/json'
                    }
                });
                if (!response.ok) {
                    if (response.status === 429 || response.status === 403) {
                        // Rate limited or forbidden, try next key
                        this.rotateApiKey();
                        continue;
                    }
                    throw new Error(`CoinMarketCap API error: ${response.status} ${response.statusText}`);
                }
                const data = await response.json();
                // Cache the response
                this.cache.set(cacheKey, {
                    data: data.data,
                    timestamp: Date.now()
                });
                return data.data;
            } catch (error) {
                lastError = error;
                this.rotateApiKey();
            }
        }
        throw new Error(`All CoinMarketCap API keys failed: ${lastError?.message || 'Unknown error'}`);
    }
    // Get token quotes by symbol
    async getTokenQuote(symbol) {
        try {
            const data = await this.makeRequest('/cryptocurrency/quotes/latest', {
                symbol: symbol.toUpperCase(),
                convert: 'USD'
            });
            const tokenData = data[symbol.toUpperCase()];
            if (!tokenData) {
                throw new Error(`Token ${symbol} not found`);
            }
            const quote = tokenData.quote.USD;
            return {
                price: quote.price || 0,
                volume_24h: quote.volume_24h || 0,
                market_cap: quote.market_cap || 0,
                percent_change_1h: quote.percent_change_1h || 0,
                percent_change_24h: quote.percent_change_24h || 0,
                percent_change_7d: quote.percent_change_7d || 0
            };
        } catch (error) {
            console.error('Failed to fetch token quote:', error);
            return {
                price: 0,
                volume_24h: 0,
                market_cap: 0,
                percent_change_1h: 0,
                percent_change_24h: 0,
                percent_change_7d: 0
            };
        }
    }
    // Get multiple token quotes
    async getMultipleQuotes(symbols) {
        try {
            const data = await this.makeRequest('/cryptocurrency/quotes/latest', {
                symbol: symbols.map((s)=>s.toUpperCase()).join(','),
                convert: 'USD'
            });
            const result = {};
            for (const symbol of symbols){
                const tokenData = data[symbol.toUpperCase()];
                if (tokenData) {
                    const quote = tokenData.quote.USD;
                    result[symbol] = {
                        price: quote.price || 0,
                        volume_24h: quote.volume_24h || 0,
                        market_cap: quote.market_cap || 0,
                        percent_change_1h: quote.percent_change_1h || 0,
                        percent_change_24h: quote.percent_change_24h || 0,
                        percent_change_7d: quote.percent_change_7d || 0
                    };
                }
            }
            return result;
        } catch (error) {
            console.error('Failed to fetch multiple quotes:', error);
            return {};
        }
    }
    // Get top cryptocurrencies
    async getTopCryptos(limit = 100) {
        try {
            const data = await this.makeRequest('/cryptocurrency/listings/latest', {
                start: '1',
                limit: limit.toString(),
                convert: 'USD',
                sort: 'market_cap'
            });
            return data.map((token)=>({
                    id: token.id,
                    name: token.name,
                    symbol: token.symbol,
                    slug: token.slug,
                    cmc_rank: token.cmc_rank,
                    market_cap: token.quote.USD.market_cap || 0,
                    price: token.quote.USD.price || 0,
                    volume_24h: token.quote.USD.volume_24h || 0,
                    percent_change_1h: token.quote.USD.percent_change_1h || 0,
                    percent_change_24h: token.quote.USD.percent_change_24h || 0,
                    percent_change_7d: token.quote.USD.percent_change_7d || 0,
                    last_updated: token.last_updated
                }));
        } catch (error) {
            console.error('Failed to fetch top cryptos:', error);
            return [];
        }
    }
    // Search for tokens
    async searchTokens(query) {
        try {
            const data = await this.makeRequest('/cryptocurrency/map', {
                symbol: query.toUpperCase(),
                limit: '10'
            });
            return data.map((token)=>({
                    id: token.id,
                    name: token.name,
                    symbol: token.symbol,
                    rank: token.rank || 9999
                }));
        } catch (error) {
            console.error('Failed to search tokens:', error);
            return [];
        }
    }
    // Get historical data
    async getHistoricalData(symbol, days = 7) {
        try {
            // Note: Historical data requires a higher plan, this is a simplified version
            const data = await this.makeRequest('/cryptocurrency/quotes/historical', {
                symbol: symbol.toUpperCase(),
                count: days.toString(),
                interval: 'daily'
            });
            return data.quotes?.map((quote)=>({
                    timestamp: new Date(quote.timestamp).getTime(),
                    price: quote.quote.USD.price || 0,
                    volume: quote.quote.USD.volume_24h || 0
                })) || [];
        } catch (error) {
            console.error('Failed to fetch historical data:', error);
            // Return mock data if API fails
            const mockData = [];
            for(let i = days; i >= 0; i--){
                mockData.push({
                    timestamp: Date.now() - i * 24 * 60 * 60 * 1000,
                    price: Math.random() * 100,
                    volume: Math.random() * 1000000
                });
            }
            return mockData;
        }
    }
    // Get global market metrics
    async getGlobalMetrics() {
        try {
            const data = await this.makeRequest('/global-metrics/quotes/latest');
            return {
                total_cryptocurrencies: data.total_cryptocurrencies || 0,
                total_market_cap: data.quote.USD.total_market_cap || 0,
                total_volume_24h: data.quote.USD.total_volume_24h || 0,
                bitcoin_dominance: data.btc_dominance || 0,
                ethereum_dominance: data.eth_dominance || 0
            };
        } catch (error) {
            console.error('Failed to fetch global metrics:', error);
            return {
                total_cryptocurrencies: 0,
                total_market_cap: 0,
                total_volume_24h: 0,
                bitcoin_dominance: 0,
                ethereum_dominance: 0
            };
        }
    }
    // Test connection
    async testConnection() {
        try {
            await this.getTokenQuote('BTC');
            return true;
        } catch  {
            return false;
        }
    }
    // Clear cache
    clearCache() {
        this.cache.clear();
    }
    // Get trending tokens
    async getTrendingTokens() {
        try {
            const topTokens = await this.getTopCryptos(20);
            // Sort by 24h change percentage
            return topTokens.sort((a, b)=>Math.abs(b.percent_change_24h) - Math.abs(a.percent_change_24h)).slice(0, 10).map((token)=>({
                    symbol: token.symbol,
                    name: token.name,
                    change_24h: token.percent_change_24h
                }));
        } catch (error) {
            console.error('Failed to fetch trending tokens:', error);
            return [];
        }
    }
}
const coinMarketCapService = new CoinMarketCapService();
const __TURBOPACK__default__export__ = CoinMarketCapService;
}),
"[project]/src/lib/services/jupiter.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Jupiter API Service - DEX Aggregation & Best Prices
// ===================================================
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "jupiterService",
    ()=>jupiterService
]);
class JupiterService {
    baseUrl;
    cache = new Map();
    cacheTimeout = 30 * 1000 // 30 seconds for quotes
    ;
    constructor(){
        this.baseUrl = process.env.JUPITER_API_URL || 'https://quote-api.jup.ag/v6';
    }
    async makeRequest(endpoint, options = {}) {
        try {
            const url = `${this.baseUrl}${endpoint}`;
            const response = await fetch(url, {
                headers: {
                    'Content-Type': 'application/json',
                    ...options.headers
                },
                ...options
            });
            if (!response.ok) {
                throw new Error(`Jupiter API error: ${response.status} ${response.statusText}`);
            }
            return await response.json();
        } catch (error) {
            console.error('Jupiter API error:', error);
            throw new Error('Failed to connect to Jupiter API');
        }
    }
    // Get quote for token swap
    async getQuote(inputMint, outputMint, amount, slippageBps = 50) {
        try {
            const params = new URLSearchParams({
                inputMint,
                outputMint,
                amount,
                slippageBps: slippageBps.toString(),
                swapMode: 'ExactIn',
                onlyDirectRoutes: 'false',
                asLegacyTransaction: 'false'
            });
            return await this.makeRequest(`/quote?${params}`);
        } catch (error) {
            console.error('Failed to get Jupiter quote:', error);
            throw new Error('Failed to get swap quote');
        }
    }
    // Get swap transaction
    async getSwapTransaction(quoteResponse, userPublicKey) {
        try {
            return await this.makeRequest('/swap', {
                method: 'POST',
                body: JSON.stringify({
                    quoteResponse,
                    userPublicKey,
                    wrapAndUnwrapSol: true,
                    useSharedAccounts: true,
                    feeAccount: undefined,
                    trackingAccount: undefined,
                    computeUnitPriceMicroLamports: 'auto',
                    prioritizationFeeLamports: 'auto',
                    asLegacyTransaction: false,
                    useTokenLedger: false,
                    destinationTokenAccount: undefined
                })
            });
        } catch (error) {
            console.error('Failed to get swap transaction:', error);
            throw new Error('Failed to create swap transaction');
        }
    }
    // Get all supported tokens
    async getTokenList() {
        const cacheKey = 'token_list';
        const cached = this.cache.get(cacheKey);
        // Use longer cache for token list (1 hour)
        if (cached && Date.now() - cached.timestamp < 60 * 60 * 1000) {
            return cached.data;
        }
        try {
            const tokens = await this.makeRequest('/tokens');
            this.cache.set(cacheKey, {
                data: tokens,
                timestamp: Date.now()
            });
            return tokens;
        } catch (error) {
            console.error('Failed to fetch token list:', error);
            return [];
        }
    }
    // Search tokens by symbol or name
    async searchTokens(query) {
        try {
            const allTokens = await this.getTokenList();
            const searchQuery = query.toLowerCase();
            return allTokens.filter((token)=>token.name.toLowerCase().includes(searchQuery) || token.symbol.toLowerCase().includes(searchQuery)).slice(0, 20) // Limit results
            ;
        } catch (error) {
            console.error('Failed to search tokens:', error);
            return [];
        }
    }
    // Get price for a token pair
    async getPrice(inputMint, outputMint, amount = '1000000000') {
        try {
            const quote = await this.getQuote(inputMint, outputMint, amount);
            const inputAmount = parseFloat(quote.inAmount);
            const outputAmount = parseFloat(quote.outAmount);
            const price = outputAmount / inputAmount;
            const route = quote.routePlan.map((plan)=>plan.swapInfo.label);
            return {
                price,
                priceImpact: parseFloat(quote.priceImpactPct),
                route: [
                    ...new Set(route)
                ] // Remove duplicates
            };
        } catch (error) {
            console.error('Failed to get price:', error);
            return {
                price: 0,
                priceImpact: 0,
                route: []
            };
        }
    }
    // Get multiple prices at once
    async getMultiplePrices(pairs) {
        try {
            const promises = pairs.map(async (pair)=>{
                try {
                    const priceData = await this.getPrice(pair.inputMint, pair.outputMint);
                    return {
                        inputMint: pair.inputMint,
                        outputMint: pair.outputMint,
                        price: priceData.price,
                        priceImpact: priceData.priceImpact
                    };
                } catch  {
                    return {
                        inputMint: pair.inputMint,
                        outputMint: pair.outputMint,
                        price: 0,
                        priceImpact: 0
                    };
                }
            });
            return await Promise.all(promises);
        } catch (error) {
            console.error('Failed to get multiple prices:', error);
            return [];
        }
    }
    // Get token info by mint address
    async getTokenInfo(mintAddress) {
        try {
            const tokens = await this.getTokenList();
            return tokens.find((token)=>token.address === mintAddress) || null;
        } catch (error) {
            console.error('Failed to get token info:', error);
            return null;
        }
    }
    // Get popular trading pairs
    async getPopularPairs() {
        try {
            // This is a simplified version - in reality you'd need more sophisticated volume tracking
            const tokens = await this.getTokenList();
            const popularTokens = tokens.filter((token)=>token.daily_volume && token.daily_volume > 100000).sort((a, b)=>(b.daily_volume || 0) - (a.daily_volume || 0)).slice(0, 20);
            const pairs = [];
            const usdcToken = tokens.find((t)=>t.symbol === 'USDC');
            const solToken = tokens.find((t)=>t.symbol === 'SOL');
            if (usdcToken && solToken) {
                for (const token of popularTokens.slice(0, 10)){
                    if (token.symbol !== 'USDC' && token.symbol !== 'SOL') {
                        pairs.push({
                            inputToken: token,
                            outputToken: usdcToken,
                            volume24h: token.daily_volume || 0
                        });
                    }
                }
            }
            return pairs;
        } catch (error) {
            console.error('Failed to get popular pairs:', error);
            return [];
        }
    }
    // Test connection
    async testConnection() {
        try {
            // Use a simpler endpoint for testing
            const response = await fetch(`${this.baseUrl}/quote?inputMint=So11111111111111111111111111111111111111112&outputMint=EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v&amount=1000000&slippageBps=50`);
            return response.ok;
        } catch  {
            return false;
        }
    }
    // Clear cache
    clearCache() {
        this.cache.clear();
    }
    // Get swap history (mock implementation)
    async getSwapHistory(userAddress) {
        // This would typically require integration with transaction history
        // For now, return empty array
        return [];
    }
}
const jupiterService = new JupiterService();
const __TURBOPACK__default__export__ = JupiterService;
}),
"[project]/src/lib/services/api-integration.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Comprehensive API Integration Service - Live Trading Platform
// =============================================================
__turbopack_context__.s([
    "apiService",
    ()=>apiService,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$deepseek$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/services/deepseek.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$helius$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/services/helius.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$coinmarketcap$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/services/coinmarketcap.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$jupiter$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/services/jupiter.ts [app-route] (ecmascript)");
;
;
;
;
class ComprehensiveAPIService {
    status = {
        deepseek: false,
        helius: false,
        coinmarketcap: false,
        jupiter: false,
        overall: false,
        errors: []
    };
    // Initialize all services and check their status
    async initialize() {
        console.log('🚀 Initializing SolX Engine API Services...');
        const statusChecks = await Promise.allSettled([
            this.checkDeepSeek(),
            this.checkHelius(),
            this.checkCoinMarketCap(),
            this.checkJupiter()
        ]);
        // Reset status
        this.status = {
            deepseek: false,
            helius: false,
            coinmarketcap: false,
            jupiter: false,
            overall: false,
            errors: []
        };
        // Process results
        statusChecks.forEach((result, index)=>{
            const services = [
                'deepseek',
                'helius',
                'coinmarketcap',
                'jupiter'
            ];
            const serviceName = services[index];
            if (result.status === 'fulfilled' && result.value) {
                this.status[serviceName] = true;
                console.log(`✅ ${serviceName.toUpperCase()} - Connected`);
            } else {
                this.status[serviceName] = false;
                const error = result.status === 'rejected' ? result.reason : 'Connection failed';
                this.status.errors.push(`${serviceName}: ${error}`);
                console.log(`❌ ${serviceName.toUpperCase()} - Failed: ${error}`);
            }
        });
        // Calculate overall status
        this.status.overall = this.status.deepseek || this.status.helius || this.status.coinmarketcap || this.status.jupiter;
        console.log(`🎯 Platform Status: ${this.status.overall ? 'OPERATIONAL' : 'LIMITED'}`);
        return this.status;
    }
    async checkDeepSeek() {
        try {
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$deepseek$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deepSeekService"].testConnection();
        } catch (error) {
            console.log('⚠️ DeepSeek check failed, OpenAI fallback available:', error);
            return false;
        }
    }
    async checkHelius() {
        try {
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$helius$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["heliusService"].testConnection();
        } catch (error) {
            console.log('⚠️ Helius check failed, using fallback RPC:', error);
            return false;
        }
    }
    async checkCoinMarketCap() {
        try {
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$coinmarketcap$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["coinMarketCapService"].testConnection();
        } catch (error) {
            console.log('⚠️ CoinMarketCap check failed:', error);
            return false;
        }
    }
    async checkJupiter() {
        try {
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$jupiter$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["jupiterService"].testConnection();
        } catch (error) {
            console.log('⚠️ Jupiter check failed:', error);
            return false;
        }
    }
    // Get comprehensive token analysis
    async analyzeToken(tokenSymbol, mintAddress) {
        try {
            console.log(`🔍 Analyzing token: ${tokenSymbol}`);
            // Gather data from all available sources
            const [cmcData, heliusData, jupiterPrice] = await Promise.allSettled([
                this.status.coinmarketcap ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$coinmarketcap$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["coinMarketCapService"].getTokenQuote(tokenSymbol) : null,
                this.status.helius && mintAddress ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$helius$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["heliusService"].getTokenInfo(mintAddress) : null,
                this.status.jupiter && mintAddress ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$jupiter$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["jupiterService"].getPrice(mintAddress, 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v') : null // USDC
            ]);
            // Extract basic data
            const cmc = cmcData.status === 'fulfilled' && cmcData.value ? cmcData.value : null;
            const helius = heliusData.status === 'fulfilled' && heliusData.value ? heliusData.value : null;
            const jupiter = jupiterPrice.status === 'fulfilled' && jupiterPrice.value ? jupiterPrice.value : null;
            const basic = {
                name: helius?.name || tokenSymbol,
                symbol: tokenSymbol,
                price: cmc?.price || jupiter?.price || 0,
                change24h: cmc?.percent_change_24h || 0,
                volume24h: cmc?.volume_24h || 0,
                marketCap: cmc?.market_cap || 0
            };
            const technical = {
                holders: helius?.holders || 0,
                liquidity: 0,
                trades24h: 0,
                priceImpact: jupiter?.priceImpact || 0
            };
            // Generate AI analysis
            let aiAnalysis = 'Analysis unavailable';
            let risk = 'medium';
            let recommendation = 'hold';
            if (this.status.deepseek) {
                try {
                    const analysis = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$deepseek$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deepSeekService"].analyzeTradingStrategy({
                        symbol: tokenSymbol,
                        price: basic.price,
                        change24h: basic.change24h,
                        volume: basic.volume24h,
                        marketCap: basic.marketCap,
                        holders: technical.holders
                    });
                    aiAnalysis = analysis;
                    // Simple risk assessment based on metrics
                    if (basic.marketCap > 10000000 && technical.holders > 1000) {
                        risk = 'low';
                    } else if (basic.marketCap > 1000000 && technical.holders > 100) {
                        risk = 'medium';
                    } else {
                        risk = 'high';
                    }
                    // Simple recommendation based on change
                    if (basic.change24h > 10) {
                        recommendation = 'sell'; // Take profits
                    } else if (basic.change24h > 5) {
                        recommendation = 'hold';
                    } else if (basic.change24h > -5) {
                        recommendation = 'buy';
                    } else {
                        recommendation = 'avoid';
                    }
                } catch (error) {
                    console.error('AI analysis failed:', error);
                }
            }
            return {
                basic,
                technical,
                ai: {
                    analysis: aiAnalysis,
                    risk,
                    recommendation
                }
            };
        } catch (error) {
            console.error('Token analysis failed:', error);
            throw new Error('Failed to analyze token');
        }
    }
    // Generate token content using AI with proper fallback
    async generateTokenContent(params) {
        // Try DeepSeek first, then OpenAI, then provide mock content
        try {
            if (this.status.deepseek) {
                console.log('🤖 Using DeepSeek AI...');
                if (params.type === 'meme') {
                    const memeContent = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$deepseek$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deepSeekService"].generateMemeTokenContent(params.name, params.description || 'fun community token');
                    return {
                        description: memeContent.description,
                        tagline: memeContent.tagline,
                        features: memeContent.features
                    };
                } else {
                    const description = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$deepseek$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deepSeekService"].generateTokenDescription(params.name, params.symbol);
                    const websiteContent = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$deepseek$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deepSeekService"].generateWebsiteContent(params.name, params.type || 'utility');
                    return {
                        description,
                        tagline: websiteContent.heroSubtitle,
                        features: websiteContent.features,
                        whitepaper: `# ${params.name} Whitepaper\n\n${description}\n\n## Features\n${websiteContent.features.map((f)=>`- ${f}`).join('\n')}`
                    };
                }
            }
        } catch (error) {
            console.log('⚠️ DeepSeek failed, trying OpenAI fallback...');
        }
        // OpenAI fallback
        try {
            const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$deepseek$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["generateWithFallback"])(`Generate professional content for token "${params.name}" (${params.symbol}). Include description, tagline, and 4 features.`, 'You are a professional crypto marketing specialist.');
            return {
                description: response.slice(0, 200) + '...',
                tagline: `The future of ${params.name}`,
                features: [
                    'Advanced Technology',
                    'Community Driven',
                    'Secure & Transparent',
                    'Innovation Focus'
                ]
            };
        } catch (error) {
            console.log('⚠️ AI services unavailable, using mock content...');
        }
        // Mock content fallback
        return {
            description: `${params.name} is a revolutionary ${params.type || 'utility'} token built on Solana blockchain. ${params.description || 'Designed to provide value to the community with innovative features and strong tokenomics.'}`,
            tagline: `The Future of ${params.type === 'meme' ? 'Meme Coins' : 'DeFi'}`,
            features: [
                params.type === 'meme' ? 'Community Driven' : 'Advanced Technology',
                params.type === 'meme' ? 'Meme Power' : 'Low Transaction Fees',
                params.type === 'meme' ? 'Diamond Hands' : 'High Security',
                params.type === 'meme' ? 'To The Moon' : 'Decentralized Governance'
            ]
        };
    }
    // Get live market data
    async getMarketData() {
        try {
            const [trending, global] = await Promise.allSettled([
                this.status.coinmarketcap ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$coinmarketcap$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["coinMarketCapService"].getTrendingTokens() : [],
                this.status.coinmarketcap ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$coinmarketcap$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["coinMarketCapService"].getGlobalMetrics() : null
            ]);
            const trendingData = trending.status === 'fulfilled' ? trending.value : [];
            const globalData = global.status === 'fulfilled' && global.value ? global.value : null;
            return {
                trending: trendingData.map((token)=>({
                        symbol: token.symbol,
                        name: token.name,
                        change24h: token.change_24h
                    })),
                globalMetrics: {
                    totalMarketCap: globalData?.total_market_cap || 0,
                    totalVolume: globalData?.total_volume_24h || 0,
                    btcDominance: globalData?.bitcoin_dominance || 0
                },
                topGainers: trendingData.filter((token)=>token.change_24h > 0).slice(0, 5).map((token)=>({
                        symbol: token.symbol,
                        name: token.name,
                        change24h: token.change_24h
                    }))
            };
        } catch (error) {
            console.error('Market data fetch failed:', error);
            return {
                trending: [],
                globalMetrics: {
                    totalMarketCap: 0,
                    totalVolume: 0,
                    btcDominance: 0
                },
                topGainers: []
            };
        }
    }
    // Get swap quote
    async getSwapQuote(inputMint, outputMint, amount) {
        if (!this.status.jupiter) {
            throw new Error('Jupiter service not available');
        }
        try {
            const quote = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$jupiter$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["jupiterService"].getQuote(inputMint, outputMint, amount);
            return {
                price: parseFloat(quote.outAmount) / parseFloat(quote.inAmount),
                priceImpact: parseFloat(quote.priceImpactPct),
                route: quote.routePlan.map((plan)=>plan.swapInfo.label),
                fee: parseFloat(quote.platformFee?.amount || '0')
            };
        } catch (error) {
            console.error('Swap quote failed:', error);
            throw new Error('Failed to get swap quote');
        }
    }
    // Get platform status
    getStatus() {
        return this.status;
    }
    // Health check
    async healthCheck() {
        const currentStatus = await this.initialize();
        const activeServices = Object.values(currentStatus).filter(Boolean).length - 2 // Exclude 'overall' and 'errors'
        ;
        let status;
        if (activeServices >= 3) {
            status = 'healthy';
        } else if (activeServices >= 1) {
            status = 'degraded';
        } else {
            status = 'down';
        }
        return {
            status,
            services: {
                deepseek: currentStatus.deepseek,
                helius: currentStatus.helius,
                coinmarketcap: currentStatus.coinmarketcap,
                jupiter: currentStatus.jupiter
            },
            uptime: Date.now(),
            errors: currentStatus.errors
        };
    }
}
const apiService = new ComprehensiveAPIService();
// Auto-initialize on import
apiService.initialize().then((status)=>{
    console.log('🎯 SolX Engine API Services initialized:', status);
}).catch((error)=>{
    console.error('❌ API Services initialization failed:', error);
});
const __TURBOPACK__default__export__ = ComprehensiveAPIService;
}),
"[project]/src/app/api/platform/status/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// API Route: Initialize Platform Services
// =====================================
__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$api$2d$integration$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/services/api-integration.ts [app-route] (ecmascript)");
;
;
async function GET(request) {
    try {
        console.log('🚀 Initializing SolX Engine Platform Services...');
        const status = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$api$2d$integration$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["apiService"].initialize();
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            message: 'Platform services initialized successfully',
            status,
            services: {
                deepseek: {
                    enabled: status.deepseek,
                    description: 'DeepSeek AI - Content generation and analysis (10x cheaper than OpenAI)'
                },
                helius: {
                    enabled: status.helius,
                    description: 'Helius - Premium Solana RPC and blockchain data'
                },
                coinmarketcap: {
                    enabled: status.coinmarketcap,
                    description: 'CoinMarketCap - Live market data and pricing'
                },
                jupiter: {
                    enabled: status.jupiter,
                    description: 'Jupiter - DEX aggregation and best price routing'
                }
            },
            overallStatus: status.overall ? 'OPERATIONAL' : 'LIMITED',
            errors: status.errors,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error('❌ Platform initialization failed:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            message: 'Platform initialization failed',
            error: error instanceof Error ? error.message : 'Unknown error',
            timestamp: new Date().toISOString()
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__dee8f9e3._.js.map