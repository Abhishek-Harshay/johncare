__turbopack_load_page_chunks__("/_error", [
  "static/chunks/d834e751564bb2f1.js",
  "static/chunks/186223a53ef706f9.js",
  "static/chunks/turbopack-2344abf1655b1eea.js"
])
