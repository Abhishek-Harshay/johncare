(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__c954ec71._.css",
  "static/chunks/node_modules_@noble_curves_esm_b26c8796._.js",
  "static/chunks/node_modules_@solana_web3_js_lib_index_browser_esm_91fb059e.js",
  "static/chunks/node_modules_@tanstack_query-core_build_modern_31e467a3._.js",
  "static/chunks/node_modules_@solana_fcaf5925._.js",
  "static/chunks/node_modules_@solana-mobile_526cc856._.js",
  "static/chunks/node_modules_c3becfe7._.js",
  "static/chunks/src_60b113f3._.js"
],
    source: "dynamic"
});
