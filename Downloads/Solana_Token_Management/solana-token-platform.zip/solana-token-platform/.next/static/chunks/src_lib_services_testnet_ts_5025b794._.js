(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/lib/services/testnet.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Testnet Configuration Service
// Provides free testing environment for users to build trust
__turbopack_context__.s([
    "TestnetService",
    ()=>TestnetService,
    "testnetService",
    ()=>testnetService
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@swc/helpers/esm/_define_property.js [app-client] (ecmascript)");
;
class TestnetService {
    static getInstance() {
        if (!TestnetService.instance) {
            TestnetService.instance = new TestnetService();
        }
        return TestnetService.instance;
    }
    getCurrentNetwork() {
        return this.networks[this.currentNetwork];
    }
    setNetwork(network) {
        this.currentNetwork = network;
        console.log("🔄 Network switched to: ".concat(network.toUpperCase()));
    }
    isTestMode() {
        return this.currentNetwork !== 'mainnet';
    }
    getNetworkInfo() {
        return this.getCurrentNetwork();
    }
    // Get appropriate RPC endpoint based on current network
    getRPCEndpoint() {
        const network = this.getCurrentNetwork();
        // Use Helius for better performance if available
        if (this.currentNetwork === 'testnet') {
            const heliusKey = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.HELIUS_API_KEY_1;
            if (heliusKey) {
                return "https://devnet.helius-rpc.com/?api-key=".concat(heliusKey);
            }
        }
        return network.rpcEndpoint;
    }
    // Get testnet SOL from faucet
    async requestTestnetSOL(publicKey) {
        if (this.currentNetwork === 'mainnet') {
            return {
                success: false,
                message: 'Faucet not available on mainnet'
            };
        }
        try {
            const network = this.getCurrentNetwork();
            if (!network.faucetUrl) {
                return {
                    success: false,
                    message: 'Faucet not available for this network'
                };
            }
            // Simulate faucet request (in real implementation, call actual faucet API)
            console.log("💧 Requesting testnet SOL for: ".concat(publicKey));
            // Mock successful faucet response
            const mockTxHash = "faucet_".concat(Date.now(), "_").concat(Math.random().toString(36).substr(2, 9));
            return {
                success: true,
                message: "Successfully airdropped 2 SOL to ".concat(publicKey.slice(0, 8), "..."),
                txHash: mockTxHash
            };
        } catch (error) {
            console.error('Faucet request failed:', error);
            return {
                success: false,
                message: 'Faucet request failed'
            };
        }
    }
    // Generate warning message for testnet usage
    getTestnetWarning() {
        if (this.currentNetwork === 'mainnet') {
            return '⚠️ You are on MAINNET - Real tokens and SOL will be used!';
        }
        return "ℹ️ You are on ".concat(this.currentNetwork.toUpperCase(), " - This is a free testing environment. No real value involved.");
    }
    // Get network-specific explorer URL
    getExplorerUrl(signature) {
        const network = this.getCurrentNetwork();
        const baseUrl = network.explorerUrl;
        if (signature) {
            return "".concat(baseUrl, "/tx/").concat(signature);
        }
        return baseUrl;
    }
    // Testnet-specific token creation parameters
    getTokenCreationConfig() {
        return {
            network: this.currentNetwork,
            isFree: this.isTestMode(),
            rpcEndpoint: this.getRPCEndpoint(),
            explorerUrl: this.getCurrentNetwork().explorerUrl,
            warning: this.getTestnetWarning(),
            features: {
                freeCreation: this.isTestMode(),
                freeLiquidity: this.isTestMode(),
                freeTransactions: this.isTestMode(),
                testnetFaucet: this.isTestMode()
            }
        };
    }
    constructor(){
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "currentNetwork", 'testnet');
        // Network configurations
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "networks", {
            mainnet: {
                network: 'mainnet',
                rpcEndpoint: 'https://api.mainnet-beta.solana.com',
                explorerUrl: 'https://explorer.solana.com',
                isFree: false
            },
            testnet: {
                network: 'testnet',
                rpcEndpoint: 'https://api.testnet.solana.com',
                explorerUrl: 'https://explorer.solana.com?cluster=testnet',
                faucetUrl: 'https://faucet.solana.com',
                isFree: true
            },
            devnet: {
                network: 'devnet',
                rpcEndpoint: 'https://api.devnet.solana.com',
                explorerUrl: 'https://explorer.solana.com?cluster=devnet',
                faucetUrl: 'https://faucet.solana.com',
                isFree: true
            }
        });
    }
}
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(TestnetService, "instance", void 0);
const testnetService = TestnetService.getInstance();
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_lib_services_testnet_ts_5025b794._.js.map