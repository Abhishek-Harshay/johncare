(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_components_sections_Jupiter_tsx_29513fc0._.js",
  "static/chunks/src_components_sections_CommunityTools_tsx_289338ef._.js",
  "static/chunks/src_components_sections_SettingsConfig_tsx_658c21a2._.js",
  "static/chunks/src_components_sections_phase7_d17b1a7c._.js",
  "static/chunks/src_components_sections_55a4e40c._.js",
  "static/chunks/src_components_bots_7858892f._.js",
  "static/chunks/src_components_274885c3._.js",
  "static/chunks/node_modules_d1a34401._.js"
],
    source: "dynamic"
});
