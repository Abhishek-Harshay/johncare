module.exports = [
"[project]/.next-internal/server/app/api/bots/volume/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/lib/services/testnet.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Testnet Configuration Service
// Provides free testing environment for users to build trust
__turbopack_context__.s([
    "TestnetService",
    ()=>TestnetService,
    "testnetService",
    ()=>testnetService
]);
class TestnetService {
    static instance;
    currentNetwork = 'testnet';
    // Network configurations
    networks = {
        mainnet: {
            network: 'mainnet',
            rpcEndpoint: 'https://api.mainnet-beta.solana.com',
            explorerUrl: 'https://explorer.solana.com',
            isFree: false
        },
        testnet: {
            network: 'testnet',
            rpcEndpoint: 'https://api.testnet.solana.com',
            explorerUrl: 'https://explorer.solana.com?cluster=testnet',
            faucetUrl: 'https://faucet.solana.com',
            isFree: true
        },
        devnet: {
            network: 'devnet',
            rpcEndpoint: 'https://api.devnet.solana.com',
            explorerUrl: 'https://explorer.solana.com?cluster=devnet',
            faucetUrl: 'https://faucet.solana.com',
            isFree: true
        }
    };
    static getInstance() {
        if (!TestnetService.instance) {
            TestnetService.instance = new TestnetService();
        }
        return TestnetService.instance;
    }
    getCurrentNetwork() {
        return this.networks[this.currentNetwork];
    }
    setNetwork(network) {
        this.currentNetwork = network;
        console.log(`🔄 Network switched to: ${network.toUpperCase()}`);
    }
    isTestMode() {
        return this.currentNetwork !== 'mainnet';
    }
    getNetworkInfo() {
        return this.getCurrentNetwork();
    }
    // Get appropriate RPC endpoint based on current network
    getRPCEndpoint() {
        const network = this.getCurrentNetwork();
        // Use Helius for better performance if available
        if (this.currentNetwork === 'testnet') {
            const heliusKey = process.env.HELIUS_API_KEY_1;
            if (heliusKey) {
                return `https://devnet.helius-rpc.com/?api-key=${heliusKey}`;
            }
        }
        return network.rpcEndpoint;
    }
    // Get testnet SOL from faucet
    async requestTestnetSOL(publicKey) {
        if (this.currentNetwork === 'mainnet') {
            return {
                success: false,
                message: 'Faucet not available on mainnet'
            };
        }
        try {
            const network = this.getCurrentNetwork();
            if (!network.faucetUrl) {
                return {
                    success: false,
                    message: 'Faucet not available for this network'
                };
            }
            // Simulate faucet request (in real implementation, call actual faucet API)
            console.log(`💧 Requesting testnet SOL for: ${publicKey}`);
            // Mock successful faucet response
            const mockTxHash = `faucet_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            return {
                success: true,
                message: `Successfully airdropped 2 SOL to ${publicKey.slice(0, 8)}...`,
                txHash: mockTxHash
            };
        } catch (error) {
            console.error('Faucet request failed:', error);
            return {
                success: false,
                message: 'Faucet request failed'
            };
        }
    }
    // Generate warning message for testnet usage
    getTestnetWarning() {
        if (this.currentNetwork === 'mainnet') {
            return '⚠️ You are on MAINNET - Real tokens and SOL will be used!';
        }
        return `ℹ️ You are on ${this.currentNetwork.toUpperCase()} - This is a free testing environment. No real value involved.`;
    }
    // Get network-specific explorer URL
    getExplorerUrl(signature) {
        const network = this.getCurrentNetwork();
        const baseUrl = network.explorerUrl;
        if (signature) {
            return `${baseUrl}/tx/${signature}`;
        }
        return baseUrl;
    }
    // Testnet-specific token creation parameters
    getTokenCreationConfig() {
        return {
            network: this.currentNetwork,
            isFree: this.isTestMode(),
            rpcEndpoint: this.getRPCEndpoint(),
            explorerUrl: this.getCurrentNetwork().explorerUrl,
            warning: this.getTestnetWarning(),
            features: {
                freeCreation: this.isTestMode(),
                freeLiquidity: this.isTestMode(),
                freeTransactions: this.isTestMode(),
                testnetFaucet: this.isTestMode()
            }
        };
    }
}
const testnetService = TestnetService.getInstance();
}),
"[project]/src/lib/services/bots/volumeBot.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Volume Bot Service
// Simulates trading activity to create volume and liquidity appearance
__turbopack_context__.s([
    "volumeBot",
    ()=>volumeBot
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$testnet$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/services/testnet.ts [app-route] (ecmascript)");
;
class VolumeBot {
    static instance;
    activeSessions = new Map();
    tradingIntervals = new Map();
    static getInstance() {
        if (!VolumeBot.instance) {
            VolumeBot.instance = new VolumeBot();
        }
        return VolumeBot.instance;
    }
    // Start a new volume session
    async startVolumeSession(config) {
        try {
            const sessionId = `vol_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            // Validate configuration
            const validation = this.validateConfig(config);
            if (!validation.valid) {
                return {
                    success: false,
                    message: validation.error || 'Invalid configuration'
                };
            }
            // Create new session
            const session = {
                id: sessionId,
                config,
                status: 'idle',
                currentVolume: 0,
                targetVolume: config.targetVolume,
                tradesExecuted: 0,
                averageTradeSize: 0,
                errors: []
            };
            this.activeSessions.set(sessionId, session);
            // Start trading
            await this.executeVolumeSession(sessionId);
            console.log(`🚀 Volume Bot session started: ${sessionId}`);
            return {
                success: true,
                sessionId,
                message: `Volume bot started with target ${config.targetVolume} ${config.baseTokenAddress === 'SOL' ? 'SOL' : 'tokens'}`
            };
        } catch (error) {
            console.error('Volume bot start error:', error);
            return {
                success: false,
                message: `Failed to start volume bot: ${error}`
            };
        }
    }
    // Execute the volume session
    async executeVolumeSession(sessionId) {
        const session = this.activeSessions.get(sessionId);
        if (!session) return;
        session.status = 'running';
        session.startTime = new Date();
        const { config } = session;
        const intervalMs = 60 / config.frequency * 1000 // Convert frequency to milliseconds
        ;
        console.log(`📊 Starting volume generation for ${config.tokenAddress}`);
        console.log(`🎯 Target: ${config.targetVolume} | Pattern: ${config.pattern} | Duration: ${config.duration}min`);
        const interval = setInterval(async ()=>{
            try {
                if (session.status !== 'running') {
                    clearInterval(interval);
                    this.tradingIntervals.delete(sessionId);
                    return;
                }
                // Check if target reached or time expired
                const elapsedMinutes = (Date.now() - session.startTime.getTime()) / 60000;
                if (session.currentVolume >= session.targetVolume || elapsedMinutes >= config.duration) {
                    await this.stopVolumeSession(sessionId, 'completed');
                    return;
                }
                // Execute trade
                await this.executeTrade(sessionId);
            } catch (error) {
                console.error(`Volume bot trade error for session ${sessionId}:`, error);
                session.errors.push(`Trade execution error: ${error}`);
                if (session.errors.length > 10) {
                    await this.stopVolumeSession(sessionId, 'error');
                }
            }
        }, intervalMs);
        this.tradingIntervals.set(sessionId, interval);
    }
    // Execute a single trade
    async executeTrade(sessionId) {
        const session = this.activeSessions.get(sessionId);
        if (!session) throw new Error('Session not found');
        const { config } = session;
        const isTestnet = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$testnet$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["testnetService"].isTestMode();
        // Calculate trade size based on pattern
        const tradeSize = this.calculateTradeSize(config, session);
        const tradeType = this.determineTradeType(config, session);
        const trade = {
            id: `trade_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
            timestamp: new Date(),
            type: tradeType,
            amount: tradeSize,
            price: await this.getCurrentPrice(config.tokenAddress),
            success: false
        };
        try {
            if (isTestnet) {
                // Simulate trade execution on testnet
                trade.success = await this.simulateTradeExecution(trade, config);
                trade.txHash = `testnet_${trade.id}`;
            } else {
                // Execute real trade on mainnet (would integrate with Jupiter/DEX)
                trade.success = await this.executeRealTrade(trade, config);
            }
            // Update session stats
            if (trade.success) {
                session.currentVolume += tradeSize;
                session.tradesExecuted += 1;
                session.averageTradeSize = session.currentVolume / session.tradesExecuted;
                console.log(`✅ ${trade.type.toUpperCase()} executed: ${tradeSize} tokens | Volume: ${session.currentVolume}/${session.targetVolume}`);
            }
        } catch (error) {
            trade.error = error instanceof Error ? error.message : String(error);
            session.errors.push(`Trade ${trade.id} failed: ${error}`);
        }
        return trade;
    }
    // Calculate trade size based on pattern and current state
    calculateTradeSize(config, session) {
        const { pattern, minTradeSize, maxTradeSize } = config;
        const progress = session.currentVolume / session.targetVolume;
        switch(pattern){
            case 'organic':
                // Random sizes with slight preference for smaller trades
                return minTradeSize + Math.random() * (maxTradeSize - minTradeSize) * (Math.random() < 0.7 ? 0.5 : 1);
            case 'burst':
                // Larger trades with bursts of activity
                return Math.random() < 0.3 ? maxTradeSize : minTradeSize;
            case 'steady':
                // Consistent trade sizes
                return minTradeSize + (maxTradeSize - minTradeSize) * 0.5;
            case 'pump':
                // Increasing trade sizes over time
                return minTradeSize + (maxTradeSize - minTradeSize) * progress;
            default:
                return minTradeSize + Math.random() * (maxTradeSize - minTradeSize);
        }
    }
    // Determine whether to buy or sell
    determineTradeType(config, session) {
        // Maintain roughly 50/50 buy/sell ratio with slight buy preference for pumping
        const random = Math.random();
        if (config.pattern === 'pump') {
            return random < 0.6 ? 'buy' : 'sell' // 60% buy for pump pattern
            ;
        }
        return random < 0.52 ? 'buy' : 'sell' // Slight buy preference for organic volume
        ;
    }
    // Get current token price (mock implementation)
    async getCurrentPrice(tokenAddress) {
        // In real implementation, this would query Jupiter or other price APIs
        return 0.001 + Math.random() * 0.01 // Mock price between 0.001 and 0.011
        ;
    }
    // Simulate trade execution for testnet
    async simulateTradeExecution(trade, config) {
        // Simulate network delay
        await new Promise((resolve)=>setTimeout(resolve, 100 + Math.random() * 200));
        // 95% success rate for simulation
        return Math.random() < 0.95;
    }
    // Execute real trade (placeholder for mainnet integration)
    async executeRealTrade(trade, config) {
        // This would integrate with Jupiter API or direct DEX interaction
        console.log(`🔄 Executing real trade: ${trade.type} ${trade.amount} tokens`);
        // For now, return simulation
        return this.simulateTradeExecution(trade, config);
    }
    // Stop a volume session
    async stopVolumeSession(sessionId, reason = 'user') {
        const session = this.activeSessions.get(sessionId);
        if (!session) return false;
        // Clear interval
        const interval = this.tradingIntervals.get(sessionId);
        if (interval) {
            clearInterval(interval);
            this.tradingIntervals.delete(sessionId);
        }
        // Update session
        session.status = reason === 'error' ? 'error' : 'completed';
        session.endTime = new Date();
        console.log(`🛑 Volume bot session ${sessionId} stopped: ${reason}`);
        console.log(`📊 Final stats: ${session.tradesExecuted} trades, ${session.currentVolume} volume`);
        return true;
    }
    // Get session status
    getSession(sessionId) {
        return this.activeSessions.get(sessionId) || null;
    }
    // Get all active sessions
    getAllSessions() {
        return Array.from(this.activeSessions.values());
    }
    // Validate configuration
    validateConfig(config) {
        if (!config.tokenAddress) {
            return {
                valid: false,
                error: 'Token address is required'
            };
        }
        if (config.targetVolume <= 0) {
            return {
                valid: false,
                error: 'Target volume must be greater than 0'
            };
        }
        if (config.duration <= 0) {
            return {
                valid: false,
                error: 'Duration must be greater than 0'
            };
        }
        if (config.minTradeSize >= config.maxTradeSize) {
            return {
                valid: false,
                error: 'Min trade size must be less than max trade size'
            };
        }
        if (config.frequency <= 0 || config.frequency > 60) {
            return {
                valid: false,
                error: 'Frequency must be between 1 and 60 trades per minute'
            };
        }
        return {
            valid: true
        };
    }
    // Pause a session
    async pauseVolumeSession(sessionId) {
        const session = this.activeSessions.get(sessionId);
        if (!session || session.status !== 'running') return false;
        session.status = 'paused';
        return true;
    }
    // Resume a session
    async resumeVolumeSession(sessionId) {
        const session = this.activeSessions.get(sessionId);
        if (!session || session.status !== 'paused') return false;
        session.status = 'running';
        return true;
    }
}
const volumeBot = VolumeBot.getInstance();
}),
"[project]/src/app/api/bots/volume/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Volume Bot API Endpoint
// Handles volume bot operations
__turbopack_context__.s([
    "GET",
    ()=>GET,
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$volumeBot$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/services/bots/volumeBot.ts [app-route] (ecmascript)");
;
;
async function POST(request) {
    try {
        const body = await request.json();
        const { action, config, sessionId } = body;
        switch(action){
            case 'start':
                if (!config) {
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                        success: false,
                        error: 'Volume configuration is required'
                    }, {
                        status: 400
                    });
                }
                const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$volumeBot$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["volumeBot"].startVolumeSession(config);
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(result);
            case 'stop':
                if (!sessionId) {
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                        success: false,
                        error: 'Session ID is required'
                    }, {
                        status: 400
                    });
                }
                const stopped = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$volumeBot$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["volumeBot"].stopVolumeSession(sessionId, 'user');
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    success: stopped,
                    message: stopped ? 'Volume bot stopped successfully' : 'Failed to stop volume bot'
                });
            case 'pause':
                if (!sessionId) {
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                        success: false,
                        error: 'Session ID is required'
                    }, {
                        status: 400
                    });
                }
                const paused = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$volumeBot$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["volumeBot"].pauseVolumeSession(sessionId);
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    success: paused,
                    message: paused ? 'Volume bot paused' : 'Failed to pause volume bot'
                });
            case 'resume':
                if (!sessionId) {
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                        success: false,
                        error: 'Session ID is required'
                    }, {
                        status: 400
                    });
                }
                const resumed = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$volumeBot$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["volumeBot"].resumeVolumeSession(sessionId);
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    success: resumed,
                    message: resumed ? 'Volume bot resumed' : 'Failed to resume volume bot'
                });
            case 'status':
                if (sessionId) {
                    const session = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$volumeBot$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["volumeBot"].getSession(sessionId);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                        success: true,
                        session
                    });
                } else {
                    const sessions = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$volumeBot$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["volumeBot"].getAllSessions();
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                        success: true,
                        sessions
                    });
                }
            default:
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    success: false,
                    error: 'Invalid action. Supported actions: start, stop, pause, resume, status'
                }, {
                    status: 400
                });
        }
    } catch (error) {
        console.error('Volume Bot API error:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: 'Internal server error',
            details: error instanceof Error ? error.message : 'Unknown error'
        }, {
            status: 500
        });
    }
}
async function GET(request) {
    try {
        const { searchParams } = new URL(request.url);
        const sessionId = searchParams.get('sessionId');
        if (sessionId) {
            const session = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$volumeBot$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["volumeBot"].getSession(sessionId);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: true,
                session
            });
        } else {
            const sessions = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$volumeBot$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["volumeBot"].getAllSessions();
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: true,
                sessions,
                count: sessions.length
            });
        }
    } catch (error) {
        console.error('Volume Bot GET API error:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: 'Internal server error'
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0178e45d._.js.map