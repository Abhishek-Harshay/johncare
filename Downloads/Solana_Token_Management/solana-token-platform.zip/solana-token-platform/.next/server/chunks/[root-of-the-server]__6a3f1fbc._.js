module.exports = [
"[project]/.next-internal/server/app/api/bots/wallet-generator/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/lib/services/testnet.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Testnet Configuration Service
// Provides free testing environment for users to build trust
__turbopack_context__.s([
    "TestnetService",
    ()=>TestnetService,
    "testnetService",
    ()=>testnetService
]);
class TestnetService {
    static instance;
    currentNetwork = 'testnet';
    // Network configurations
    networks = {
        mainnet: {
            network: 'mainnet',
            rpcEndpoint: 'https://api.mainnet-beta.solana.com',
            explorerUrl: 'https://explorer.solana.com',
            isFree: false
        },
        testnet: {
            network: 'testnet',
            rpcEndpoint: 'https://api.testnet.solana.com',
            explorerUrl: 'https://explorer.solana.com?cluster=testnet',
            faucetUrl: 'https://faucet.solana.com',
            isFree: true
        },
        devnet: {
            network: 'devnet',
            rpcEndpoint: 'https://api.devnet.solana.com',
            explorerUrl: 'https://explorer.solana.com?cluster=devnet',
            faucetUrl: 'https://faucet.solana.com',
            isFree: true
        }
    };
    static getInstance() {
        if (!TestnetService.instance) {
            TestnetService.instance = new TestnetService();
        }
        return TestnetService.instance;
    }
    getCurrentNetwork() {
        return this.networks[this.currentNetwork];
    }
    setNetwork(network) {
        this.currentNetwork = network;
        console.log(`🔄 Network switched to: ${network.toUpperCase()}`);
    }
    isTestMode() {
        return this.currentNetwork !== 'mainnet';
    }
    getNetworkInfo() {
        return this.getCurrentNetwork();
    }
    // Get appropriate RPC endpoint based on current network
    getRPCEndpoint() {
        const network = this.getCurrentNetwork();
        // Use Helius for better performance if available
        if (this.currentNetwork === 'testnet') {
            const heliusKey = process.env.HELIUS_API_KEY_1;
            if (heliusKey) {
                return `https://devnet.helius-rpc.com/?api-key=${heliusKey}`;
            }
        }
        return network.rpcEndpoint;
    }
    // Get testnet SOL from faucet
    async requestTestnetSOL(publicKey) {
        if (this.currentNetwork === 'mainnet') {
            return {
                success: false,
                message: 'Faucet not available on mainnet'
            };
        }
        try {
            const network = this.getCurrentNetwork();
            if (!network.faucetUrl) {
                return {
                    success: false,
                    message: 'Faucet not available for this network'
                };
            }
            // Simulate faucet request (in real implementation, call actual faucet API)
            console.log(`💧 Requesting testnet SOL for: ${publicKey}`);
            // Mock successful faucet response
            const mockTxHash = `faucet_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            return {
                success: true,
                message: `Successfully airdropped 2 SOL to ${publicKey.slice(0, 8)}...`,
                txHash: mockTxHash
            };
        } catch (error) {
            console.error('Faucet request failed:', error);
            return {
                success: false,
                message: 'Faucet request failed'
            };
        }
    }
    // Generate warning message for testnet usage
    getTestnetWarning() {
        if (this.currentNetwork === 'mainnet') {
            return '⚠️ You are on MAINNET - Real tokens and SOL will be used!';
        }
        return `ℹ️ You are on ${this.currentNetwork.toUpperCase()} - This is a free testing environment. No real value involved.`;
    }
    // Get network-specific explorer URL
    getExplorerUrl(signature) {
        const network = this.getCurrentNetwork();
        const baseUrl = network.explorerUrl;
        if (signature) {
            return `${baseUrl}/tx/${signature}`;
        }
        return baseUrl;
    }
    // Testnet-specific token creation parameters
    getTokenCreationConfig() {
        return {
            network: this.currentNetwork,
            isFree: this.isTestMode(),
            rpcEndpoint: this.getRPCEndpoint(),
            explorerUrl: this.getCurrentNetwork().explorerUrl,
            warning: this.getTestnetWarning(),
            features: {
                freeCreation: this.isTestMode(),
                freeLiquidity: this.isTestMode(),
                freeTransactions: this.isTestMode(),
                testnetFaucet: this.isTestMode()
            }
        };
    }
}
const testnetService = TestnetService.getInstance();
}),
"[externals]/buffer [external] (buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}),
"[externals]/node:crypto [external] (node:crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:crypto", () => require("node:crypto"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/punycode [external] (punycode, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("punycode", () => require("punycode"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[externals]/net [external] (net, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}),
"[externals]/tls [external] (tls, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/node:url [external] (node:url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:url", () => require("node:url"));

module.exports = mod;
}),
"[project]/src/lib/services/bots/bulkWalletGenerator.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bulkWalletGeneratorService",
    ()=>bulkWalletGeneratorService
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$testnet$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/services/testnet.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/web3.js/lib/index.esm.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bs58$2f$src$2f$esm$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/bs58/src/esm/index.js [app-route] (ecmascript)");
;
;
;
class BulkWalletGeneratorService {
    sessions = new Map();
    wallets = new Map();
    // Generate unique session ID
    generateSessionId() {
        return `wallet_gen_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }
    // Generate a single Solana wallet
    generateSolanaWallet(id, prefix) {
        try {
            const keypair = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$web3$2e$js$2f$lib$2f$index$2e$esm$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Keypair"].generate();
            const publicKey = keypair.publicKey.toBase58();
            const privateKey = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bs58$2f$src$2f$esm$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].encode(keypair.secretKey);
            return {
                id,
                publicKey: prefix ? `${prefix}_${publicKey}` : publicKey,
                privateKey,
                createdAt: new Date().toISOString(),
                balance: 0,
                isActive: true
            };
        } catch (error) {
            throw new Error(`Failed to generate wallet ${id}: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    // Generate mnemonic phrase (simulation for demo)
    generateMnemonic() {
        const words = [
            'abandon',
            'ability',
            'able',
            'about',
            'above',
            'absent',
            'absorb',
            'abstract',
            'absurd',
            'abuse',
            'access',
            'accident',
            'account',
            'accuse',
            'achieve',
            'acid',
            'acoustic',
            'acquire',
            'across',
            'act',
            'action',
            'actor',
            'actress',
            'actual',
            'adapt',
            'add',
            'addict',
            'address',
            'adjust',
            'admit',
            'adult',
            'advance',
            'advice',
            'aerobic',
            'affair',
            'afford',
            'afraid',
            'again',
            'against',
            'agent',
            'agree',
            'ahead',
            'aim',
            'air',
            'airport',
            'aisle',
            'alarm',
            'album',
            'alcohol',
            'alert',
            'alien',
            'all',
            'alley',
            'allow',
            'almost',
            'alone'
        ];
        return Array.from({
            length: 12
        }, ()=>words[Math.floor(Math.random() * words.length)]).join(' ');
    }
    // Start bulk wallet generation
    async startGeneration(config) {
        try {
            // Validate configuration
            if (config.count < 1 || config.count > 100000) {
                return {
                    success: false,
                    message: 'Wallet count must be between 1 and 100,000'
                };
            }
            const sessionId = this.generateSessionId();
            const session = {
                id: sessionId,
                config,
                status: 'generating',
                startTime: new Date().toISOString(),
                walletsGenerated: 0,
                targetCount: config.count,
                errors: []
            };
            this.sessions.set(sessionId, session);
            this.wallets.set(sessionId, []);
            // Start generation process
            this.generateWalletsBatch(sessionId);
            return {
                success: true,
                sessionId,
                message: 'Bulk wallet generation started'
            };
        } catch (error) {
            console.error('Failed to start wallet generation:', error);
            return {
                success: false,
                message: 'Failed to start wallet generation'
            };
        }
    }
    // Generate wallets in batches
    async generateWalletsBatch(sessionId) {
        const session = this.sessions.get(sessionId);
        if (!session) return;
        const batchSize = 100 // Generate 100 wallets at a time
        ;
        const { config } = session;
        try {
            while(session.walletsGenerated < config.count && session.status === 'generating'){
                const remainingWallets = config.count - session.walletsGenerated;
                const currentBatchSize = Math.min(batchSize, remainingWallets);
                // Generate batch of wallets
                const batch = [];
                for(let i = 0; i < currentBatchSize; i++){
                    const walletId = session.walletsGenerated + i + 1;
                    const wallet = this.generateSolanaWallet(walletId, config.walletPrefix);
                    // Add mnemonic if requested
                    if (config.generateMnemonics) {
                        wallet.mnemonic = this.generateMnemonic();
                    }
                    batch.push(wallet);
                }
                // Add batch to session wallets
                const existingWallets = this.wallets.get(sessionId) || [];
                this.wallets.set(sessionId, [
                    ...existingWallets,
                    ...batch
                ]);
                // Update session progress
                session.walletsGenerated += currentBatchSize;
                this.sessions.set(sessionId, session);
                const isTestMode = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$testnet$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["testnetService"].isTestMode();
                console.log(`${isTestMode ? '🧪 [TESTNET]' : '💼 [MAINNET]'} Generated batch: ${session.walletsGenerated}/${config.count} wallets`);
                // Small delay to prevent overwhelming the system
                await new Promise((resolve)=>setTimeout(resolve, 10));
            }
            // Complete generation
            if (session.walletsGenerated >= config.count) {
                session.status = 'completed';
                session.endTime = new Date().toISOString();
                this.sessions.set(sessionId, session);
                console.log(`✅ Wallet generation completed: ${session.walletsGenerated} wallets generated`);
            }
        } catch (error) {
            console.error('Error in wallet generation batch:', error);
            session.status = 'error';
            session.errors.push(`Generation error: ${error instanceof Error ? error.message : 'Unknown error'}`);
            this.sessions.set(sessionId, session);
        }
    }
    // Get session status
    getSession(sessionId) {
        return this.sessions.get(sessionId) || null;
    }
    // Get all sessions
    getAllSessions() {
        return Array.from(this.sessions.values());
    }
    // Get wallets for session
    getSessionWallets(sessionId) {
        return this.wallets.get(sessionId) || [];
    }
    // Export wallets in different formats
    exportWallets(sessionId, format) {
        const wallets = this.wallets.get(sessionId);
        const session = this.sessions.get(sessionId);
        if (!wallets || !session) return null;
        const includePrivateKeys = session.config.includePrivateKeys;
        switch(format){
            case 'json':
                return JSON.stringify(wallets.map((wallet)=>({
                        id: wallet.id,
                        publicKey: wallet.publicKey,
                        ...includePrivateKeys && {
                            privateKey: wallet.privateKey
                        },
                        ...wallet.mnemonic && {
                            mnemonic: wallet.mnemonic
                        },
                        createdAt: wallet.createdAt,
                        balance: wallet.balance
                    })), null, 2);
            case 'csv':
                const headers = [
                    'ID',
                    'PublicKey',
                    ...includePrivateKeys ? [
                        'PrivateKey'
                    ] : [],
                    ...session.config.generateMnemonics ? [
                        'Mnemonic'
                    ] : [],
                    'CreatedAt',
                    'Balance'
                ];
                const rows = wallets.map((wallet)=>[
                        wallet.id.toString(),
                        wallet.publicKey,
                        ...includePrivateKeys ? [
                            wallet.privateKey
                        ] : [],
                        ...wallet.mnemonic ? [
                            wallet.mnemonic
                        ] : [],
                        wallet.createdAt,
                        wallet.balance.toString()
                    ]);
                return [
                    headers.join(','),
                    ...rows.map((row)=>row.join(','))
                ].join('\n');
            case 'txt':
                return wallets.map((wallet)=>{
                    let line = `${wallet.id}. ${wallet.publicKey}`;
                    if (includePrivateKeys) {
                        line += ` | ${wallet.privateKey}`;
                    }
                    if (wallet.mnemonic) {
                        line += ` | ${wallet.mnemonic}`;
                    }
                    return line;
                }).join('\n');
            default:
                return null;
        }
    }
    // Get wallet statistics
    getWalletStats(sessionId) {
        const wallets = this.wallets.get(sessionId);
        const session = this.sessions.get(sessionId);
        if (!wallets || !session) return null;
        const activeWallets = wallets.filter((w)=>w.isActive);
        const totalBalance = wallets.reduce((sum, w)=>sum + w.balance, 0);
        const walletsWith0Balance = wallets.filter((w)=>w.balance === 0).length;
        let generationTime = 0;
        if (session.startTime && session.endTime) {
            generationTime = new Date(session.endTime).getTime() - new Date(session.startTime).getTime();
        }
        return {
            totalWallets: wallets.length,
            activeWallets: activeWallets.length,
            totalBalance,
            averageBalance: wallets.length > 0 ? totalBalance / wallets.length : 0,
            walletsWith0Balance,
            generationTime
        };
    }
    // Delete session and associated data
    deleteSession(sessionId) {
        const session = this.sessions.get(sessionId);
        if (!session) {
            return {
                success: false,
                message: 'Session not found'
            };
        }
        this.sessions.delete(sessionId);
        this.wallets.delete(sessionId);
        return {
            success: true,
            message: 'Session deleted successfully'
        };
    }
    // Get wallet by public key
    findWallet(sessionId, publicKey) {
        const wallets = this.wallets.get(sessionId);
        if (!wallets) return null;
        return wallets.find((w)=>w.publicKey === publicKey) || null;
    }
    // Update wallet balance (for tracking purposes)
    updateWalletBalance(sessionId, publicKey, balance) {
        const wallets = this.wallets.get(sessionId);
        if (!wallets) return false;
        const wallet = wallets.find((w)=>w.publicKey === publicKey);
        if (!wallet) return false;
        wallet.balance = balance;
        this.wallets.set(sessionId, wallets);
        return true;
    }
    // Cleanup old sessions
    cleanup() {
        let cleaned = 0;
        const cutoffTime = Date.now() - 7 * 24 * 60 * 60 * 1000 // 7 days ago
        ;
        for (const [sessionId, session] of this.sessions.entries()){
            if (session.status === 'completed' && session.endTime) {
                const endTime = new Date(session.endTime).getTime();
                if (endTime < cutoffTime) {
                    this.sessions.delete(sessionId);
                    this.wallets.delete(sessionId);
                    cleaned++;
                }
            }
        }
        if (cleaned > 0) {
            console.log(`🧹 Cleaned up ${cleaned} old wallet generation sessions`);
        }
        return cleaned;
    }
}
const bulkWalletGeneratorService = new BulkWalletGeneratorService();
}),
"[project]/src/app/api/bots/wallet-generator/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET,
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$bulkWalletGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/services/bots/bulkWalletGenerator.ts [app-route] (ecmascript)");
;
;
async function GET(request) {
    try {
        const { searchParams } = new URL(request.url);
        const sessionId = searchParams.get('sessionId');
        const action = searchParams.get('action');
        if (sessionId && action === 'export') {
            // Export wallets
            const format = searchParams.get('format') || 'json';
            const session = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$bulkWalletGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bulkWalletGeneratorService"].getSession(sessionId);
            if (!session) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    success: false,
                    message: 'Session not found'
                }, {
                    status: 404
                });
            }
            const exportData = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$bulkWalletGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bulkWalletGeneratorService"].exportWallets(sessionId, format);
            if (!exportData) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    success: false,
                    message: 'No wallet data found for export'
                }, {
                    status: 404
                });
            }
            const mimeTypes = {
                json: 'application/json',
                csv: 'text/csv',
                txt: 'text/plain'
            };
            const filenames = {
                json: `wallets_${sessionId}.json`,
                csv: `wallets_${sessionId}.csv`,
                txt: `wallets_${sessionId}.txt`
            };
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"](exportData, {
                status: 200,
                headers: {
                    'Content-Type': mimeTypes[format],
                    'Content-Disposition': `attachment; filename="${filenames[format]}"`
                }
            });
        }
        if (sessionId && action === 'stats') {
            // Get wallet statistics
            const stats = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$bulkWalletGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bulkWalletGeneratorService"].getWalletStats(sessionId);
            if (!stats) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    success: false,
                    message: 'No stats available for this session'
                }, {
                    status: 404
                });
            }
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: true,
                stats
            });
        }
        if (sessionId) {
            // Get specific session
            const session = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$bulkWalletGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bulkWalletGeneratorService"].getSession(sessionId);
            if (!session) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    success: false,
                    message: 'Session not found'
                }, {
                    status: 404
                });
            }
            const includeWallets = searchParams.get('includeWallets') === 'true';
            const wallets = includeWallets ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$bulkWalletGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bulkWalletGeneratorService"].getSessionWallets(sessionId) : undefined;
            const stats = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$bulkWalletGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bulkWalletGeneratorService"].getWalletStats(sessionId);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: true,
                session: {
                    ...session,
                    ...wallets && {
                        wallets
                    },
                    stats
                }
            });
        }
        // Get all sessions
        const sessions = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$bulkWalletGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bulkWalletGeneratorService"].getAllSessions();
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            sessions,
            count: sessions.length
        });
    } catch (error) {
        console.error('Bulk Wallet Generator API Error (GET):', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            message: 'Internal server error'
        }, {
            status: 500
        });
    }
}
async function POST(request) {
    try {
        const body = await request.json();
        const { action, config, sessionId } = body;
        switch(action){
            case 'generate':
                {
                    if (!config) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Configuration is required'
                        }, {
                            status: 400
                        });
                    }
                    // Validate required fields
                    if (!config.count || config.count < 1 || config.count > 100000) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Count must be between 1 and 100,000'
                        }, {
                            status: 400
                        });
                    }
                    // Start new wallet generation session
                    const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$bulkWalletGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bulkWalletGeneratorService"].startGeneration({
                        count: parseInt(config.count),
                        format: config.format || 'json',
                        includePrivateKeys: Boolean(config.includePrivateKeys),
                        walletPrefix: config.walletPrefix || undefined,
                        generateMnemonics: Boolean(config.generateMnemonics)
                    });
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(result, {
                        status: result.success ? 200 : 400
                    });
                }
            case 'status':
                {
                    if (!sessionId) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Session ID is required'
                        }, {
                            status: 400
                        });
                    }
                    const session = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$bulkWalletGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bulkWalletGeneratorService"].getSession(sessionId);
                    if (!session) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Session not found'
                        }, {
                            status: 404
                        });
                    }
                    const stats = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$bulkWalletGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bulkWalletGeneratorService"].getWalletStats(sessionId);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                        success: true,
                        session: {
                            ...session,
                            stats
                        }
                    });
                }
            case 'delete':
                {
                    if (!sessionId) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Session ID is required'
                        }, {
                            status: 400
                        });
                    }
                    const result = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$bulkWalletGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bulkWalletGeneratorService"].deleteSession(sessionId);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(result, {
                        status: result.success ? 200 : 404
                    });
                }
            case 'find-wallet':
                {
                    if (!sessionId || !body.publicKey) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Session ID and public key are required'
                        }, {
                            status: 400
                        });
                    }
                    const wallet = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$bulkWalletGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bulkWalletGeneratorService"].findWallet(sessionId, body.publicKey);
                    if (!wallet) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Wallet not found'
                        }, {
                            status: 404
                        });
                    }
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                        success: true,
                        wallet
                    });
                }
            case 'update-balance':
                {
                    if (!sessionId || !body.publicKey || typeof body.balance !== 'number') {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Session ID, public key, and balance are required'
                        }, {
                            status: 400
                        });
                    }
                    const updated = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$bulkWalletGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bulkWalletGeneratorService"].updateWalletBalance(sessionId, body.publicKey, body.balance);
                    if (!updated) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Failed to update wallet balance'
                        }, {
                            status: 404
                        });
                    }
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                        success: true,
                        message: 'Wallet balance updated'
                    });
                }
            case 'cleanup':
                {
                    const cleaned = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$bulkWalletGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["bulkWalletGeneratorService"].cleanup();
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                        success: true,
                        message: `Cleaned up ${cleaned} old sessions`,
                        cleanedSessions: cleaned
                    });
                }
            default:
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    success: false,
                    message: 'Invalid action. Supported actions: generate, status, delete, find-wallet, update-balance, cleanup'
                }, {
                    status: 400
                });
        }
    } catch (error) {
        console.error('Bulk Wallet Generator API Error (POST):', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            message: error instanceof Error ? error.message : 'Internal server error',
            error: ("TURBOPACK compile-time truthy", 1) ? error : "TURBOPACK unreachable"
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__6a3f1fbc._.js.map