__turbopack_load_page_chunks__("/_app", [
  "static/chunks/20d5dd762530bc91.js",
  "static/chunks/186223a53ef706f9.js",
  "static/chunks/turbopack-83eca361c4417e53.js"
])
