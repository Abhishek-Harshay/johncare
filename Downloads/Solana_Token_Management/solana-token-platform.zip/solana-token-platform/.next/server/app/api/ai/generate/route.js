var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/generate/route.js")
R.c("server/chunks/[root-of-the-server]__ec4712e3._.js")
R.c("server/chunks/node_modules_next_317e10ab._.js")
R.m(356638)
R.m(859165)
module.exports=R.m(859165).exports
