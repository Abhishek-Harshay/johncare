(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_solx_page_tsx_1611a7ea._.js",
  "static/chunks/node_modules_a9cdcfe3._.js"
],
    source: "dynamic"
});
