module.exports = [
"[project]/.next-internal/server/app/api/bots/legal-docs/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/lib/services/bots/legalDocGenerator.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "legalDocGeneratorService",
    ()=>legalDocGeneratorService
]);
class LegalDocGeneratorService {
    static instance;
    sessions = new Map();
    static getInstance() {
        if (!LegalDocGeneratorService.instance) {
            LegalDocGeneratorService.instance = new LegalDocGeneratorService();
        }
        return LegalDocGeneratorService.instance;
    }
    // Start document generation session
    async startGeneration(config) {
        try {
            const sessionId = `legal_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            const session = {
                id: sessionId,
                config,
                status: 'generating',
                startTime: new Date().toISOString(),
                documents: [],
                progress: 0,
                errors: []
            };
            this.sessions.set(sessionId, session);
            // Start generation process
            this.processDocumentGeneration(sessionId);
            return {
                success: true,
                sessionId,
                message: 'Legal document generation started'
            };
        } catch (error) {
            return {
                success: false,
                message: `Failed to start generation: ${error instanceof Error ? error.message : 'Unknown error'}`
            };
        }
    }
    // Process document generation
    async processDocumentGeneration(sessionId) {
        const session = this.sessions.get(sessionId);
        if (!session) return;
        try {
            const documents = [];
            const totalSteps = this.getDocumentCount(session.config.docType);
            let currentStep = 0;
            // Generate documents based on type
            if (session.config.docType === 'terms' || session.config.docType === 'full-package') {
                documents.push(await this.generateTermsOfService(session.config));
                currentStep++;
                session.progress = Math.round(currentStep / totalSteps * 100);
                this.sessions.set(sessionId, {
                    ...session
                });
            }
            if (session.config.docType === 'privacy' || session.config.docType === 'full-package') {
                documents.push(await this.generatePrivacyPolicy(session.config));
                currentStep++;
                session.progress = Math.round(currentStep / totalSteps * 100);
                this.sessions.set(sessionId, {
                    ...session
                });
            }
            if (session.config.docType === 'disclaimer' || session.config.docType === 'full-package') {
                documents.push(await this.generateLegalDisclaimer(session.config));
                currentStep++;
                session.progress = Math.round(currentStep / totalSteps * 100);
                this.sessions.set(sessionId, {
                    ...session
                });
            }
            if (session.config.docType === 'compliance' || session.config.docType === 'full-package') {
                documents.push(await this.generateComplianceDoc(session.config));
                currentStep++;
                session.progress = Math.round(currentStep / totalSteps * 100);
                this.sessions.set(sessionId, {
                    ...session
                });
            }
            if (session.config.docType === 'whitepaper' || session.config.docType === 'full-package') {
                documents.push(await this.generateWhitepaper(session.config));
                currentStep++;
                session.progress = Math.round(currentStep / totalSteps * 100);
                this.sessions.set(sessionId, {
                    ...session
                });
            }
            // Complete session
            session.status = 'completed';
            session.endTime = new Date().toISOString();
            session.documents = documents;
            session.progress = 100;
            this.sessions.set(sessionId, session);
        } catch (error) {
            session.status = 'error';
            session.errors.push(error instanceof Error ? error.message : 'Unknown error');
            this.sessions.set(sessionId, session);
        }
    }
    // Generate Terms of Service
    async generateTermsOfService(config) {
        const sections = [
            {
                title: "1. Acceptance of Terms",
                content: `By accessing and using ${config.tokenName} (${config.tokenSymbol}) and related services provided by ${config.companyName}, you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our services.`,
                isRequired: true,
                riskLevel: 'low'
            },
            {
                title: "2. Token Description",
                content: `${config.tokenName} (${config.tokenSymbol}) is a digital token built on the Solana blockchain. The token serves the following purposes: ${config.tokenPurpose}. Token utilities include: ${config.tokenUtility.join(', ')}.`,
                isRequired: true,
                riskLevel: 'medium'
            },
            {
                title: "3. Token Economics",
                content: `Total Maximum Supply: ${config.maxSupply.toLocaleString()} ${config.tokenSymbol}. Initial Supply: ${config.initialSupply.toLocaleString()} ${config.tokenSymbol}. Token distribution and economics are subject to the terms outlined in our whitepaper and technical documentation.`,
                isRequired: true,
                riskLevel: 'high'
            },
            {
                title: "4. Risk Warnings",
                content: `IMPORTANT: Cryptocurrency investments involve substantial risk. The value of ${config.tokenSymbol} may fluctuate significantly. You may lose all or part of your investment. Past performance does not guarantee future results. Regulatory changes may affect token value and utility.`,
                isRequired: true,
                riskLevel: 'high'
            },
            {
                title: "5. Compliance and Legal",
                content: `Users must comply with all applicable laws and regulations in their jurisdiction. ${config.companyName} reserves the right to restrict access to users from certain jurisdictions. This agreement is governed by the laws of ${config.jurisdiction}.`,
                isRequired: true,
                riskLevel: 'high'
            }
        ];
        if (config.includeKYC) {
            sections.push({
                title: "6. Know Your Customer (KYC)",
                content: `Users may be required to complete KYC verification before accessing certain services. We reserve the right to request additional documentation to verify identity and comply with regulatory requirements.`,
                isRequired: true,
                riskLevel: 'medium'
            });
        }
        if (config.includeAML) {
            sections.push({
                title: "7. Anti-Money Laundering (AML)",
                content: `We maintain strict AML policies and procedures. Suspicious transactions will be reported to relevant authorities. Users agree to cooperate with any AML investigations or compliance requests.`,
                isRequired: true,
                riskLevel: 'medium'
            });
        }
        const content = sections.map((section)=>`${section.title}\n\n${section.content}\n\n`).join('');
        return {
            type: 'terms',
            title: `Terms of Service - ${config.tokenName}`,
            content,
            lastUpdated: new Date().toISOString(),
            wordCount: content.split(' ').length,
            sections
        };
    }
    // Generate Privacy Policy
    async generatePrivacyPolicy(config) {
        const sections = [
            {
                title: "1. Information We Collect",
                content: `${config.companyName} collects information necessary to provide ${config.tokenName} services, including: wallet addresses, transaction data, IP addresses, device information, and communication records.`,
                isRequired: true,
                riskLevel: 'medium'
            },
            {
                title: "2. How We Use Information",
                content: `We use collected information to: provide and improve our services, ensure security and compliance, communicate with users, and fulfill legal obligations. We do not sell personal information to third parties.`,
                isRequired: true,
                riskLevel: 'low'
            },
            {
                title: "3. Data Security",
                content: `We implement industry-standard security measures to protect user data. However, no system is completely secure. Users are responsible for securing their own wallets and private keys.`,
                isRequired: true,
                riskLevel: 'high'
            },
            {
                title: "4. Data Retention",
                content: `We retain user data as long as necessary to provide services and comply with legal obligations. Users may request data deletion subject to legal and regulatory requirements.`,
                isRequired: true,
                riskLevel: 'medium'
            }
        ];
        if (config.includeGDPR) {
            sections.push({
                title: "5. GDPR Rights (EU Users)",
                content: `EU users have rights under GDPR including: access to personal data, data portability, rectification, erasure (right to be forgotten), and objection to processing. Contact our Data Protection Officer to exercise these rights.`,
                isRequired: true,
                riskLevel: 'medium'
            });
        }
        if (config.includeCCPA) {
            sections.push({
                title: "6. CCPA Rights (California Users)",
                content: `California residents have rights under CCPA including: right to know what personal information is collected, right to delete personal information, right to opt-out of sale, and right to non-discrimination.`,
                isRequired: true,
                riskLevel: 'medium'
            });
        }
        const content = sections.map((section)=>`${section.title}\n\n${section.content}\n\n`).join('');
        return {
            type: 'privacy',
            title: `Privacy Policy - ${config.tokenName}`,
            content,
            lastUpdated: new Date().toISOString(),
            wordCount: content.split(' ').length,
            sections
        };
    }
    // Generate Legal Disclaimer
    async generateLegalDisclaimer(config) {
        const sections = [
            {
                title: "Investment Risk Disclaimer",
                content: `${config.tokenName} (${config.tokenSymbol}) is a high-risk investment. Cryptocurrency markets are highly volatile and speculative. You should never invest more than you can afford to lose. Consult with financial advisors before making investment decisions.`,
                isRequired: true,
                riskLevel: 'high'
            },
            {
                title: "No Investment Advice",
                content: `Information provided by ${config.companyName} does not constitute investment, financial, trading, or other advice. We do not recommend any specific course of action. All decisions are solely your responsibility.`,
                isRequired: true,
                riskLevel: 'high'
            },
            {
                title: "Regulatory Uncertainty",
                content: `Cryptocurrency regulations are evolving and uncertain. Regulatory changes may negatively impact ${config.tokenSymbol} value, utility, or legality. Users are responsible for understanding applicable laws in their jurisdiction.`,
                isRequired: true,
                riskLevel: 'high'
            },
            {
                title: "Technology Risks",
                content: `Blockchain technology involves risks including: smart contract vulnerabilities, network congestion, hard forks, and technological obsolescence. ${config.companyName} cannot guarantee the technical stability of ${config.tokenSymbol}.`,
                isRequired: true,
                riskLevel: 'high'
            },
            {
                title: "No Guarantees",
                content: `${config.companyName} makes no warranties or guarantees regarding ${config.tokenSymbol} performance, utility, or value. Token features and roadmap are subject to change without notice.`,
                isRequired: true,
                riskLevel: 'high'
            }
        ];
        const content = sections.map((section)=>`${section.title}\n\n${section.content}\n\n`).join('');
        return {
            type: 'disclaimer',
            title: `Legal Disclaimer - ${config.tokenName}`,
            content,
            lastUpdated: new Date().toISOString(),
            wordCount: content.split(' ').length,
            sections
        };
    }
    // Generate Compliance Documentation
    async generateComplianceDoc(config) {
        const sections = [
            {
                title: "Regulatory Framework",
                content: `${config.companyName} operates under the regulatory framework of ${config.jurisdiction}. We monitor regulatory developments in target jurisdictions: ${config.targetJurisdictions.join(', ')}.`,
                isRequired: true,
                riskLevel: 'high'
            },
            {
                title: "Token Classification",
                content: `${config.tokenName} is classified as a utility token providing access to platform services. The token is not intended as a security, investment contract, or financial instrument under applicable securities laws.`,
                isRequired: true,
                riskLevel: 'high'
            },
            {
                title: "Compliance Procedures",
                content: `We maintain comprehensive compliance procedures including: regular legal reviews, transaction monitoring, suspicious activity reporting, and cooperation with regulatory authorities.`,
                isRequired: true,
                riskLevel: 'medium'
            }
        ];
        if (config.includeKYC) {
            sections.push({
                title: "KYC/AML Compliance",
                content: `Our KYC/AML program includes: customer identification procedures, ongoing monitoring, sanctions screening, and suspicious transaction reporting. We use third-party verification services to ensure compliance.`,
                isRequired: true,
                riskLevel: 'medium'
            });
        }
        const content = sections.map((section)=>`${section.title}\n\n${section.content}\n\n`).join('');
        return {
            type: 'compliance',
            title: `Compliance Documentation - ${config.tokenName}`,
            content,
            lastUpdated: new Date().toISOString(),
            wordCount: content.split(' ').length,
            sections
        };
    }
    // Generate Whitepaper
    async generateWhitepaper(config) {
        const sections = [
            {
                title: "Executive Summary",
                content: `${config.tokenName} (${config.tokenSymbol}) is a blockchain-based digital asset designed to ${config.tokenPurpose}. Built on the Solana network, the token provides utility through: ${config.tokenUtility.join(', ')}.`,
                isRequired: true,
                riskLevel: 'low'
            },
            {
                title: "Technology Overview",
                content: `${config.tokenName} leverages Solana's high-performance blockchain infrastructure, capable of processing thousands of transactions per second with minimal fees. The token follows SPL token standards ensuring compatibility with Solana ecosystem tools.`,
                isRequired: true,
                riskLevel: 'low'
            },
            {
                title: "Tokenomics",
                content: `Total Supply: ${config.maxSupply.toLocaleString()} ${config.tokenSymbol}\nInitial Supply: ${config.initialSupply.toLocaleString()} ${config.tokenSymbol}\n\nToken distribution is designed to ensure long-term sustainability and community growth while maintaining appropriate incentive structures.`,
                isRequired: true,
                riskLevel: 'medium'
            },
            {
                title: "Use Cases",
                content: `${config.tokenSymbol} serves multiple utility functions within our ecosystem: ${config.tokenUtility.map((utility)=>`• ${utility}`).join('\n')}`,
                isRequired: true,
                riskLevel: 'low'
            },
            {
                title: "Legal and Compliance",
                content: `${config.companyName} is committed to regulatory compliance across all operating jurisdictions. The token is designed as a utility asset and not as a security or investment instrument.`,
                isRequired: true,
                riskLevel: 'high'
            }
        ];
        const content = sections.map((section)=>`${section.title}\n\n${section.content}\n\n`).join('');
        return {
            type: 'whitepaper',
            title: `${config.tokenName} Whitepaper`,
            content,
            lastUpdated: new Date().toISOString(),
            wordCount: content.split(' ').length,
            sections
        };
    }
    // Get document count for progress tracking
    getDocumentCount(docType) {
        const counts = {
            'terms': 1,
            'privacy': 1,
            'disclaimer': 1,
            'compliance': 1,
            'whitepaper': 1,
            'full-package': 5
        };
        return counts[docType] || 1;
    }
    // Get session
    getSession(sessionId) {
        return this.sessions.get(sessionId) || null;
    }
    // Get all sessions
    getAllSessions() {
        return Array.from(this.sessions.values());
    }
    // Delete session
    deleteSession(sessionId) {
        return this.sessions.delete(sessionId);
    }
    // Export documents as ZIP
    exportDocuments(sessionId) {
        const session = this.sessions.get(sessionId);
        if (!session) {
            return {
                success: false,
                message: 'Session not found'
            };
        }
        if (session.status !== 'completed') {
            return {
                success: false,
                message: 'Session not completed'
            };
        }
        try {
            // Create exportable data structure
            const exportData = {
                sessionId,
                generatedAt: new Date().toISOString(),
                companyInfo: {
                    name: session.config.companyName,
                    address: session.config.companyAddress,
                    website: session.config.companyWebsite
                },
                tokenInfo: {
                    name: session.config.tokenName,
                    symbol: session.config.tokenSymbol,
                    purpose: session.config.tokenPurpose
                },
                documents: session.documents.map((doc)=>({
                        type: doc.type,
                        title: doc.title,
                        content: doc.content,
                        wordCount: doc.wordCount,
                        sections: doc.sections.length
                    }))
            };
            return {
                success: true,
                data: JSON.stringify(exportData, null, 2),
                message: 'Documents exported successfully'
            };
        } catch (error) {
            return {
                success: false,
                message: `Export failed: ${error instanceof Error ? error.message : 'Unknown error'}`
            };
        }
    }
    // Validate legal compliance
    validateCompliance(config) {
        const warnings = [];
        const errors = [];
        // Check required fields
        if (!config.companyName) errors.push('Company name is required');
        if (!config.tokenName) errors.push('Token name is required');
        if (!config.tokenSymbol) errors.push('Token symbol is required');
        if (!config.jurisdiction) errors.push('Jurisdiction is required');
        // Check token economics
        if (config.maxSupply <= 0) errors.push('Max supply must be greater than 0');
        if (config.initialSupply > config.maxSupply) errors.push('Initial supply cannot exceed max supply');
        // Risk level warnings
        if (config.riskLevel === 'high' && !config.includeKYC) {
            warnings.push('High-risk tokens should consider KYC requirements');
        }
        if (config.targetJurisdictions.includes('US') && !config.includeCCPA) {
            warnings.push('US operations should consider CCPA compliance');
        }
        if (config.targetJurisdictions.some((j)=>[
                'EU',
                'UK',
                'Germany',
                'France'
            ].includes(j)) && !config.includeGDPR) {
            warnings.push('EU operations should consider GDPR compliance');
        }
        return {
            isValid: errors.length === 0,
            warnings,
            errors
        };
    }
    // Cleanup old sessions
    cleanup() {
        const now = Date.now();
        const maxAge = 24 * 60 * 60 * 1000 // 24 hours
        ;
        let cleaned = 0;
        const total = this.sessions.size;
        for (const [sessionId, session] of this.sessions.entries()){
            const sessionAge = now - new Date(session.startTime || 0).getTime();
            if (sessionAge > maxAge && session.status !== 'generating') {
                this.sessions.delete(sessionId);
                cleaned++;
            }
        }
        return {
            cleaned,
            total
        };
    }
}
const legalDocGeneratorService = LegalDocGeneratorService.getInstance();
}),
"[project]/src/app/api/bots/legal-docs/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DELETE",
    ()=>DELETE,
    "GET",
    ()=>GET,
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$legalDocGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/services/bots/legalDocGenerator.ts [app-route] (ecmascript)");
;
;
async function GET(request) {
    try {
        const { searchParams } = new URL(request.url);
        const sessionId = searchParams.get('sessionId');
        const action = searchParams.get('action');
        if (sessionId && action === 'export') {
            // Export documents
            const result = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$legalDocGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["legalDocGeneratorService"].exportDocuments(sessionId);
            if (result.success && result.data) {
                return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"](result.data, {
                    status: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'Content-Disposition': `attachment; filename="legal_docs_${sessionId}.json"`
                    }
                });
            } else {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    success: false,
                    message: result.message
                }, {
                    status: 400
                });
            }
        }
        if (sessionId && action === 'validate') {
            // Get validation results
            const session = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$legalDocGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["legalDocGeneratorService"].getSession(sessionId);
            if (!session) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    success: false,
                    message: 'Session not found'
                }, {
                    status: 404
                });
            }
            const validation = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$legalDocGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["legalDocGeneratorService"].validateCompliance(session.config);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: true,
                validation
            });
        }
        if (sessionId) {
            // Get specific session
            const session = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$legalDocGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["legalDocGeneratorService"].getSession(sessionId);
            if (!session) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    success: false,
                    message: 'Session not found'
                }, {
                    status: 404
                });
            }
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: true,
                session
            });
        }
        // Get all sessions
        const sessions = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$legalDocGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["legalDocGeneratorService"].getAllSessions();
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            sessions
        });
    } catch (error) {
        console.error('Legal doc generator GET error:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            message: 'Failed to process request'
        }, {
            status: 500
        });
    }
}
async function POST(request) {
    try {
        const body = await request.json();
        const { action } = body;
        switch(action){
            case 'start':
                {
                    const { config } = body;
                    if (!config) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Configuration is required'
                        }, {
                            status: 400
                        });
                    }
                    // Validate configuration
                    const validation = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$legalDocGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["legalDocGeneratorService"].validateCompliance(config);
                    if (!validation.isValid) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Configuration validation failed',
                            errors: validation.errors,
                            warnings: validation.warnings
                        }, {
                            status: 400
                        });
                    }
                    const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$legalDocGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["legalDocGeneratorService"].startGeneration(config);
                    if (result.success) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: true,
                            sessionId: result.sessionId,
                            message: result.message,
                            warnings: validation.warnings
                        });
                    } else {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: result.message
                        }, {
                            status: 400
                        });
                    }
                }
            case 'delete':
                {
                    const { sessionId } = body;
                    if (!sessionId) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Session ID is required'
                        }, {
                            status: 400
                        });
                    }
                    const deleted = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$legalDocGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["legalDocGeneratorService"].deleteSession(sessionId);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                        success: deleted,
                        message: deleted ? 'Session deleted successfully' : 'Session not found'
                    });
                }
            case 'validate':
                {
                    const { config } = body;
                    if (!config) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Configuration is required for validation'
                        }, {
                            status: 400
                        });
                    }
                    const validation = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$legalDocGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["legalDocGeneratorService"].validateCompliance(config);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                        success: true,
                        validation
                    });
                }
            case 'cleanup':
                {
                    const result = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$legalDocGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["legalDocGeneratorService"].cleanup();
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                        success: true,
                        message: `Cleaned up ${result.cleaned} of ${result.total} sessions`
                    });
                }
            default:
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    success: false,
                    message: 'Invalid action'
                }, {
                    status: 400
                });
        }
    } catch (error) {
        console.error('Legal doc generator POST error:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            message: 'Failed to process request'
        }, {
            status: 500
        });
    }
}
async function DELETE(request) {
    try {
        const { searchParams } = new URL(request.url);
        const sessionId = searchParams.get('sessionId');
        if (!sessionId) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                message: 'Session ID is required'
            }, {
                status: 400
            });
        }
        const deleted = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$legalDocGenerator$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["legalDocGeneratorService"].deleteSession(sessionId);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: deleted,
            message: deleted ? 'Session deleted successfully' : 'Session not found'
        });
    } catch (error) {
        console.error('Legal doc generator DELETE error:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            message: 'Failed to delete session'
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__4d17c3a1._.js.map