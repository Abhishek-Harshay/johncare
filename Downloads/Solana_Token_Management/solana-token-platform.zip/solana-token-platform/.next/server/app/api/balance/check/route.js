var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/balance/check/route.js")
R.c("server/chunks/[root-of-the-server]__b6ab79f6._.js")
R.c("server/chunks/[root-of-the-server]__a6f7b379._.js")
R.c("server/chunks/_6ff7fb2b._.js")
R.c("server/chunks/node_modules_next_317e10ab._.js")
R.m(792698)
R.m(515170)
module.exports=R.m(515170).exports
