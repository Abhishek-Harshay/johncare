var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/token/create/route.js")
R.c("server/chunks/[root-of-the-server]__368d8126._.js")
R.c("server/chunks/[root-of-the-server]__a6f7b379._.js")
R.c("server/chunks/_6ff7fb2b._.js")
R.c("server/chunks/node_modules_next_317e10ab._.js")
R.m(712335)
R.m(407846)
module.exports=R.m(407846).exports
