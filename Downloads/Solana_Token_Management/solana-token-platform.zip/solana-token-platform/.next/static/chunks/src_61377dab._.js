(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/lib/services/testnet.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Testnet Configuration Service
// Provides free testing environment for users to build trust
__turbopack_context__.s([
    "TestnetService",
    ()=>TestnetService,
    "testnetService",
    ()=>testnetService
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@swc/helpers/esm/_define_property.js [app-client] (ecmascript)");
;
class TestnetService {
    static getInstance() {
        if (!TestnetService.instance) {
            TestnetService.instance = new TestnetService();
        }
        return TestnetService.instance;
    }
    getCurrentNetwork() {
        return this.networks[this.currentNetwork];
    }
    setNetwork(network) {
        this.currentNetwork = network;
        console.log("🔄 Network switched to: ".concat(network.toUpperCase()));
    }
    isTestMode() {
        return this.currentNetwork !== 'mainnet';
    }
    getNetworkInfo() {
        return this.getCurrentNetwork();
    }
    // Get appropriate RPC endpoint based on current network
    getRPCEndpoint() {
        const network = this.getCurrentNetwork();
        // Use Helius for better performance if available
        if (this.currentNetwork === 'testnet') {
            const heliusKey = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.HELIUS_API_KEY_1;
            if (heliusKey) {
                return "https://devnet.helius-rpc.com/?api-key=".concat(heliusKey);
            }
        }
        return network.rpcEndpoint;
    }
    // Get testnet SOL from faucet
    async requestTestnetSOL(publicKey) {
        if (this.currentNetwork === 'mainnet') {
            return {
                success: false,
                message: 'Faucet not available on mainnet'
            };
        }
        try {
            const network = this.getCurrentNetwork();
            if (!network.faucetUrl) {
                return {
                    success: false,
                    message: 'Faucet not available for this network'
                };
            }
            // Simulate faucet request (in real implementation, call actual faucet API)
            console.log("💧 Requesting testnet SOL for: ".concat(publicKey));
            // Mock successful faucet response
            const mockTxHash = "faucet_".concat(Date.now(), "_").concat(Math.random().toString(36).substr(2, 9));
            return {
                success: true,
                message: "Successfully airdropped 2 SOL to ".concat(publicKey.slice(0, 8), "..."),
                txHash: mockTxHash
            };
        } catch (error) {
            console.error('Faucet request failed:', error);
            return {
                success: false,
                message: 'Faucet request failed'
            };
        }
    }
    // Generate warning message for testnet usage
    getTestnetWarning() {
        if (this.currentNetwork === 'mainnet') {
            return '⚠️ You are on MAINNET - Real tokens and SOL will be used!';
        }
        return "ℹ️ You are on ".concat(this.currentNetwork.toUpperCase(), " - This is a free testing environment. No real value involved.");
    }
    // Get network-specific explorer URL
    getExplorerUrl(signature) {
        const network = this.getCurrentNetwork();
        const baseUrl = network.explorerUrl;
        if (signature) {
            return "".concat(baseUrl, "/tx/").concat(signature);
        }
        return baseUrl;
    }
    // Testnet-specific token creation parameters
    getTokenCreationConfig() {
        return {
            network: this.currentNetwork,
            isFree: this.isTestMode(),
            rpcEndpoint: this.getRPCEndpoint(),
            explorerUrl: this.getCurrentNetwork().explorerUrl,
            warning: this.getTestnetWarning(),
            features: {
                freeCreation: this.isTestMode(),
                freeLiquidity: this.isTestMode(),
                freeTransactions: this.isTestMode(),
                testnetFaucet: this.isTestMode()
            }
        };
    }
    constructor(){
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "currentNetwork", 'testnet');
        // Network configurations
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, "networks", {
            mainnet: {
                network: 'mainnet',
                rpcEndpoint: 'https://api.mainnet-beta.solana.com',
                explorerUrl: 'https://explorer.solana.com',
                isFree: false
            },
            testnet: {
                network: 'testnet',
                rpcEndpoint: 'https://api.testnet.solana.com',
                explorerUrl: 'https://explorer.solana.com?cluster=testnet',
                faucetUrl: 'https://faucet.solana.com',
                isFree: true
            },
            devnet: {
                network: 'devnet',
                rpcEndpoint: 'https://api.devnet.solana.com',
                explorerUrl: 'https://explorer.solana.com?cluster=devnet',
                faucetUrl: 'https://faucet.solana.com',
                isFree: true
            }
        });
    }
}
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_define_property$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(TestnetService, "instance", void 0);
const testnetService = TestnetService.getInstance();
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/providers/WalletProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WalletProvider",
    ()=>WalletProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$react$2f$lib$2f$esm$2f$ConnectionProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/wallet-adapter-react/lib/esm/ConnectionProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$react$2f$lib$2f$esm$2f$WalletProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/wallet-adapter-react/lib/esm/WalletProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$react$2d$ui$2f$lib$2f$esm$2f$WalletModalProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/wallet-adapter-react-ui/lib/esm/WalletModalProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$phantom$2f$lib$2f$esm$2f$adapter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@solana/wallet-adapter-phantom/lib/esm/adapter.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$testnet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/services/testnet.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function WalletProvider(param) {
    let { children } = param;
    _s();
    // Get network from testnet service (defaults to testnet for trust building)
    const networkConfig = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$testnet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["testnetService"].getNetworkInfo();
    const endpoint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "WalletProvider.useMemo[endpoint]": ()=>{
            // Use testnet service RPC endpoint for better performance
            return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$testnet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["testnetService"].getRPCEndpoint();
        }
    }["WalletProvider.useMemo[endpoint]"], [
        networkConfig.network
    ]);
    const wallets = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "WalletProvider.useMemo[wallets]": ()=>{
            try {
                return [
                    new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$phantom$2f$lib$2f$esm$2f$adapter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PhantomWalletAdapter"]()
                ];
            } catch (error) {
                console.warn('Wallet adapter initialization warning:', error);
                // Return empty array if wallet adapters fail to initialize
                return [];
            }
        }
    }["WalletProvider.useMemo[wallets]"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$react$2f$lib$2f$esm$2f$ConnectionProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectionProvider"], {
        endpoint: endpoint,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$react$2f$lib$2f$esm$2f$WalletProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletProvider"], {
            wallets: wallets,
            autoConnect: false,
            onError: (error)=>{
                console.warn('Wallet error (this is normal if Phantom is not installed):', error.message);
            // Don't throw error, just log it
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$solana$2f$wallet$2d$adapter$2d$react$2d$ui$2f$lib$2f$esm$2f$WalletModalProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletModalProvider"], {
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/providers/WalletProvider.tsx",
                lineNumber: 50,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/providers/WalletProvider.tsx",
            lineNumber: 42,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/providers/WalletProvider.tsx",
        lineNumber: 41,
        columnNumber: 5
    }, this);
}
_s(WalletProvider, "RNaTq20PjYTGasfEtgZ8qKkPMD0=");
_c = WalletProvider;
var _c;
__turbopack_context__.k.register(_c, "WalletProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/providers/QueryProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "QueryProvider",
    ()=>QueryProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/query-core/build/modern/queryClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function QueryProvider(param) {
    let { children } = param;
    _s();
    const [queryClient] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "QueryProvider.useState": ()=>new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClient"]({
                defaultOptions: {
                    queries: {
                        staleTime: 60 * 1000,
                        retry: 1
                    }
                }
            })
    }["QueryProvider.useState"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClientProvider"], {
        client: queryClient,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/components/providers/QueryProvider.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, this);
}
_s(QueryProvider, "7Gbm7QxUvi1tKl8zlyv3ihqO3Ko=");
_c = QueryProvider;
var _c;
__turbopack_context__.k.register(_c, "QueryProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ErrorSuppression.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ErrorSuppression
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
function ErrorSuppression() {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ErrorSuppression.useEffect": ()=>{
            // Suppress common wallet-related errors that don't affect functionality
            const originalError = console.error;
            console.error = ({
                "ErrorSuppression.useEffect": function() {
                    for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                        args[_key] = arguments[_key];
                    }
                    var _args_;
                    const message = ((_args_ = args[0]) === null || _args_ === void 0 ? void 0 : _args_.toString()) || '';
                    // Suppress Phantom wallet-related errors that are expected when wallet is not installed
                    if (message.includes('window.solana') || message.includes('Phantom') || message.includes('Unable to set window.solana')) {
                        // Log as warning instead of error
                        console.warn('ℹ️ Wallet not detected (this is normal):', ...args);
                        return;
                    }
                    // Log all other errors normally
                    originalError.apply(console, args);
                }
            })["ErrorSuppression.useEffect"];
            return ({
                "ErrorSuppression.useEffect": ()=>{
                    console.error = originalError;
                }
            })["ErrorSuppression.useEffect"];
        }
    }["ErrorSuppression.useEffect"], []);
    return null;
}
_s(ErrorSuppression, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = ErrorSuppression;
var _c;
__turbopack_context__.k.register(_c, "ErrorSuppression");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_61377dab._.js.map