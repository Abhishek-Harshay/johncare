module.exports = [
"[project]/.next-internal/server/app/api/bots/compliance/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/lib/services/bots/complianceChecker.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "complianceCheckerService",
    ()=>complianceCheckerService
]);
class ComplianceCheckerService {
    static instance;
    sessions = new Map();
    static getInstance() {
        if (!ComplianceCheckerService.instance) {
            ComplianceCheckerService.instance = new ComplianceCheckerService();
        }
        return ComplianceCheckerService.instance;
    }
    // Start compliance analysis
    async startAnalysis(config) {
        try {
            const sessionId = `compliance_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            const session = {
                id: sessionId,
                config,
                status: 'analyzing',
                startTime: new Date().toISOString(),
                errors: []
            };
            this.sessions.set(sessionId, session);
            // Start analysis process
            this.processComplianceAnalysis(sessionId);
            return {
                success: true,
                sessionId,
                message: 'Compliance analysis started'
            };
        } catch (error) {
            return {
                success: false,
                message: `Failed to start analysis: ${error instanceof Error ? error.message : 'Unknown error'}`
            };
        }
    }
    // Process compliance analysis
    async processComplianceAnalysis(sessionId) {
        const session = this.sessions.get(sessionId);
        if (!session) return;
        try {
            // Simulate analysis delay
            await new Promise((resolve)=>setTimeout(resolve, 2000));
            const result = this.analyzeCompliance(session.config);
            session.result = result;
            session.status = 'completed';
            session.endTime = new Date().toISOString();
            this.sessions.set(sessionId, session);
        } catch (error) {
            session.status = 'error';
            session.errors.push(error instanceof Error ? error.message : 'Unknown error');
            this.sessions.set(sessionId, session);
        }
    }
    // Analyze compliance
    analyzeCompliance(config) {
        let score = 0;
        const recommendations = [];
        const requirements = [];
        const warnings = [];
        const jurisdictionAnalysis = [];
        // Token Type Analysis
        if (config.tokenType === 'security') {
            score -= 20;
            warnings.push({
                type: 'regulatory',
                severity: 'high',
                message: 'Security tokens require extensive compliance across most jurisdictions',
                solution: 'Consider reclassifying as utility token or implement full securities compliance'
            });
        } else if (config.tokenType === 'utility') {
            score += 15;
        }
        // Investment Contract Analysis (Howey Test)
        const howeyFactors = {
            investmentOfMoney: config.fundingMethod !== 'airdrop' && config.fundingMethod !== 'fair-launch',
            commonEnterprise: true,
            expectationOfProfits: config.promisesReturns,
            effortsOfOthers: !config.hasGovernanceRights || !config.teamDoxxed
        };
        const howeyScore = Object.values(howeyFactors).filter(Boolean).length;
        if (howeyScore >= 3) {
            score -= 25;
            warnings.push({
                type: 'legal',
                severity: 'high',
                message: 'Project may be classified as a security under Howey Test',
                solution: 'Implement securities compliance or restructure token economics'
            });
        }
        // KYC/AML Compliance
        if (config.hasKYC && config.hasAML) {
            score += 20;
        } else {
            score -= 10;
            recommendations.push({
                category: 'Regulatory Compliance',
                priority: 'high',
                title: 'Implement KYC/AML Procedures',
                description: 'Know Your Customer and Anti-Money Laundering procedures are required in most jurisdictions',
                actionItems: [
                    'Partner with KYC/AML service provider',
                    'Implement user verification system',
                    'Create suspicious activity monitoring',
                    'Establish reporting procedures'
                ],
                estimatedCost: '$5,000 - $15,000 setup + ongoing fees',
                timeline: '2-4 weeks'
            });
        }
        // Documentation Requirements
        const docScore = [
            config.hasWhitepaper,
            config.hasTerms,
            config.hasPrivacyPolicy,
            config.hasRiskDisclosure
        ].filter(Boolean).length;
        score += docScore * 5;
        if (!config.hasRiskDisclosure) {
            warnings.push({
                type: 'documentation',
                severity: 'high',
                message: 'Risk disclosure is legally required in most jurisdictions',
                solution: 'Create comprehensive risk disclosure document'
            });
        }
        // Team and Corporate Structure
        if (config.teamDoxxed && config.hasLegalEntity) {
            score += 15;
        } else if (!config.teamDoxxed) {
            score -= 10;
            warnings.push({
                type: 'legal',
                severity: 'medium',
                message: 'Anonymous teams face increased regulatory scrutiny',
                solution: 'Consider partial or full team disclosure'
            });
        }
        // Audit and Insurance
        if (config.auditCompleted) {
            score += 10;
        } else {
            recommendations.push({
                category: 'Technical Security',
                priority: 'high',
                title: 'Complete Smart Contract Audit',
                description: 'Professional security audit builds trust and identifies vulnerabilities',
                actionItems: [
                    'Select reputable audit firm',
                    'Schedule comprehensive audit',
                    'Address identified issues',
                    'Publish audit results'
                ],
                estimatedCost: '$15,000 - $50,000',
                timeline: '2-6 weeks'
            });
        }
        if (config.insuranceCoverage) {
            score += 5;
        }
        // Jurisdiction-specific analysis
        for (const jurisdiction of config.targetMarkets){
            jurisdictionAnalysis.push(this.analyzeJurisdiction(jurisdiction, config));
        }
        // Calculate final metrics
        const maxScore = 100;
        const normalizedScore = Math.max(0, Math.min(maxScore, score + 50)) // Normalize to 0-100
        ;
        const riskLevel = this.calculateRiskLevel(normalizedScore, warnings);
        const complianceGrade = this.calculateGrade(normalizedScore);
        return {
            overallScore: normalizedScore,
            riskLevel,
            complianceGrade,
            recommendations,
            requirements,
            warnings,
            jurisdictionAnalysis
        };
    }
    // Analyze specific jurisdiction
    analyzeJurisdiction(jurisdiction, config) {
        const baseAnalysis = {
            jurisdiction,
            regulatoryFramework: '',
            tokenClassification: '',
            requiredCompliance: [],
            prohibitions: [],
            recommendations: [],
            riskLevel: 'medium'
        };
        switch(jurisdiction.toLowerCase()){
            case 'us':
            case 'united states':
                return {
                    ...baseAnalysis,
                    regulatoryFramework: 'SEC, CFTC, FinCEN oversight',
                    tokenClassification: config.isInvestmentContract ? 'Likely Security' : 'Potentially Utility',
                    requiredCompliance: [
                        'Securities Registration or Exemption',
                        'AML/BSA',
                        'State Money Transmitter Licenses'
                    ],
                    prohibitions: [
                        'Unregistered securities offerings',
                        'Market manipulation'
                    ],
                    recommendations: [
                        'Legal opinion on token classification',
                        'Implement accredited investor verification'
                    ],
                    riskLevel: config.isInvestmentContract ? 'high' : 'medium'
                };
            case 'eu':
            case 'european union':
                return {
                    ...baseAnalysis,
                    regulatoryFramework: 'MiCA Regulation (2024+)',
                    tokenClassification: 'Crypto-asset under MiCA',
                    requiredCompliance: [
                        'MiCA Authorization',
                        'GDPR',
                        'AML5 Directive'
                    ],
                    prohibitions: [
                        'Unauthorized crypto-asset services',
                        'Privacy violations'
                    ],
                    recommendations: [
                        'MiCA compliance assessment',
                        'Data protection impact assessment'
                    ],
                    riskLevel: 'medium'
                };
            case 'uk':
            case 'united kingdom':
                return {
                    ...baseAnalysis,
                    regulatoryFramework: 'FCA oversight',
                    tokenClassification: config.isInvestmentContract ? 'Security Token' : 'Exchange Token',
                    requiredCompliance: [
                        'FCA Authorization',
                        'AML Regulations',
                        'Financial Promotions Order'
                    ],
                    prohibitions: [
                        'Unauthorized financial services',
                        'Misleading promotions'
                    ],
                    recommendations: [
                        'FCA perimeter guidance review',
                        'Financial promotion compliance'
                    ],
                    riskLevel: 'medium'
                };
            case 'singapore':
                return {
                    ...baseAnalysis,
                    regulatoryFramework: 'MAS Payment Services Act',
                    tokenClassification: config.isInvestmentContract ? 'Capital Markets Product' : 'Digital Payment Token',
                    requiredCompliance: [
                        'MAS License',
                        'AML/CFT',
                        'Technology Risk Management'
                    ],
                    prohibitions: [
                        'Unlicensed payment services',
                        'Securities offerings without prospectus'
                    ],
                    recommendations: [
                        'Token classification assessment',
                        'MAS consultation'
                    ],
                    riskLevel: 'low'
                };
            default:
                return {
                    ...baseAnalysis,
                    regulatoryFramework: 'Jurisdiction-specific regulations apply',
                    tokenClassification: 'Subject to local classification',
                    requiredCompliance: [
                        'Local registration requirements',
                        'AML compliance'
                    ],
                    prohibitions: [
                        'Varies by jurisdiction'
                    ],
                    recommendations: [
                        'Seek local legal counsel',
                        'Monitor regulatory developments'
                    ],
                    riskLevel: 'medium'
                };
        }
    }
    // Calculate risk level
    calculateRiskLevel(score, warnings) {
        const highSeverityWarnings = warnings.filter((w)=>w.severity === 'high').length;
        if (score < 30 || highSeverityWarnings >= 3) return 'critical';
        if (score < 50 || highSeverityWarnings >= 2) return 'high';
        if (score < 70 || highSeverityWarnings >= 1) return 'medium';
        return 'low';
    }
    // Calculate compliance grade
    calculateGrade(score) {
        if (score >= 95) return 'A+';
        if (score >= 90) return 'A';
        if (score >= 85) return 'B+';
        if (score >= 80) return 'B';
        if (score >= 70) return 'C+';
        if (score >= 60) return 'C';
        if (score >= 50) return 'D';
        return 'F';
    }
    // Get session
    getSession(sessionId) {
        return this.sessions.get(sessionId) || null;
    }
    // Get all sessions
    getAllSessions() {
        return Array.from(this.sessions.values());
    }
    // Delete session
    deleteSession(sessionId) {
        return this.sessions.delete(sessionId);
    }
    // Export compliance report
    exportReport(sessionId) {
        const session = this.sessions.get(sessionId);
        if (!session) {
            return {
                success: false,
                message: 'Session not found'
            };
        }
        if (session.status !== 'completed' || !session.result) {
            return {
                success: false,
                message: 'Analysis not completed'
            };
        }
        try {
            const report = {
                projectName: session.config.projectName,
                tokenSymbol: session.config.tokenSymbol,
                analysisDate: session.endTime,
                overallScore: session.result.overallScore,
                complianceGrade: session.result.complianceGrade,
                riskLevel: session.result.riskLevel,
                summary: {
                    totalRecommendations: session.result.recommendations.length,
                    criticalWarnings: session.result.warnings.filter((w)=>w.severity === 'high').length,
                    jurisdictionsAnalyzed: session.result.jurisdictionAnalysis.length
                },
                recommendations: session.result.recommendations,
                warnings: session.result.warnings,
                jurisdictionAnalysis: session.result.jurisdictionAnalysis,
                requirements: session.result.requirements
            };
            return {
                success: true,
                data: JSON.stringify(report, null, 2),
                message: 'Report exported successfully'
            };
        } catch (error) {
            return {
                success: false,
                message: `Export failed: ${error instanceof Error ? error.message : 'Unknown error'}`
            };
        }
    }
    // Cleanup old sessions
    cleanup() {
        const now = Date.now();
        const maxAge = 24 * 60 * 60 * 1000 // 24 hours
        ;
        let cleaned = 0;
        const total = this.sessions.size;
        for (const [sessionId, session] of this.sessions.entries()){
            const sessionAge = now - new Date(session.startTime).getTime();
            if (sessionAge > maxAge && session.status !== 'analyzing') {
                this.sessions.delete(sessionId);
                cleaned++;
            }
        }
        return {
            cleaned,
            total
        };
    }
}
const complianceCheckerService = ComplianceCheckerService.getInstance();
}),
"[project]/src/app/api/bots/compliance/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DELETE",
    ()=>DELETE,
    "GET",
    ()=>GET,
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$complianceChecker$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/services/bots/complianceChecker.ts [app-route] (ecmascript)");
;
;
async function GET(request) {
    try {
        const { searchParams } = new URL(request.url);
        const sessionId = searchParams.get('sessionId');
        const action = searchParams.get('action');
        if (sessionId && action === 'export') {
            // Export compliance report
            const result = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$complianceChecker$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["complianceCheckerService"].exportReport(sessionId);
            if (result.success && result.data) {
                return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"](result.data, {
                    status: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'Content-Disposition': `attachment; filename="compliance_report_${sessionId}.json"`
                    }
                });
            } else {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    success: false,
                    message: result.message
                }, {
                    status: 400
                });
            }
        }
        if (sessionId) {
            // Get specific session
            const session = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$complianceChecker$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["complianceCheckerService"].getSession(sessionId);
            if (!session) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    success: false,
                    message: 'Session not found'
                }, {
                    status: 404
                });
            }
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: true,
                session
            });
        }
        // Get all sessions
        const sessions = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$complianceChecker$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["complianceCheckerService"].getAllSessions();
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            sessions
        });
    } catch (error) {
        console.error('Compliance checker GET error:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            message: 'Failed to process request'
        }, {
            status: 500
        });
    }
}
async function POST(request) {
    try {
        const body = await request.json();
        const { action } = body;
        switch(action){
            case 'start':
                {
                    const { config } = body;
                    if (!config) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Configuration is required'
                        }, {
                            status: 400
                        });
                    }
                    // Validate required fields
                    if (!config.projectName || !config.tokenSymbol) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Project name and token symbol are required'
                        }, {
                            status: 400
                        });
                    }
                    const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$complianceChecker$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["complianceCheckerService"].startAnalysis(config);
                    if (result.success) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: true,
                            sessionId: result.sessionId,
                            message: result.message
                        });
                    } else {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: result.message
                        }, {
                            status: 400
                        });
                    }
                }
            case 'delete':
                {
                    const { sessionId } = body;
                    if (!sessionId) {
                        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                            success: false,
                            message: 'Session ID is required'
                        }, {
                            status: 400
                        });
                    }
                    const deleted = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$complianceChecker$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["complianceCheckerService"].deleteSession(sessionId);
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                        success: deleted,
                        message: deleted ? 'Session deleted successfully' : 'Session not found'
                    });
                }
            case 'cleanup':
                {
                    const result = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$complianceChecker$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["complianceCheckerService"].cleanup();
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                        success: true,
                        message: `Cleaned up ${result.cleaned} of ${result.total} sessions`
                    });
                }
            default:
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    success: false,
                    message: 'Invalid action'
                }, {
                    status: 400
                });
        }
    } catch (error) {
        console.error('Compliance checker POST error:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            message: 'Failed to process request'
        }, {
            status: 500
        });
    }
}
async function DELETE(request) {
    try {
        const { searchParams } = new URL(request.url);
        const sessionId = searchParams.get('sessionId');
        if (!sessionId) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                message: 'Session ID is required'
            }, {
                status: 400
            });
        }
        const deleted = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2f$bots$2f$complianceChecker$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["complianceCheckerService"].deleteSession(sessionId);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: deleted,
            message: deleted ? 'Session deleted successfully' : 'Session not found'
        });
    } catch (error) {
        console.error('Compliance checker DELETE error:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            message: 'Failed to delete session'
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__97b0869c._.js.map